package serveur;

import ihm.server.Ihm_Serveur;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import jeton.Jeton;
import jeton.JetonSafra;
import jeton.JetonStop;
import jeton.JetonTraitement;
import pack.IObservable;
import pack.IObserver;
import pack.Machine;
import reseau.IReseau;
import traitement_image.TypeTraitement;

/**
 * Classe definissant toutes les informations relatives à un serveur ainsi que
 * les fonctions accessibles à celui-ci (connexion à la machine réseau,
 * réception et traitement des requêtes des clients, partage de la charge de
 * travail avec le serveurs suivant, exécution du processus de terminaison etc)
 * 
 * @author Amine TALBI & Hugues FAGNINOU
 * 
 */
public class Serveur extends UnicastRemoteObject implements IServeur,
		IObservable {

	private static final long serialVersionUID = 1L;
	Machine machineServeur;
	Machine clientTraite;
	ThreadServeur[] listeThreadServeur;
	Machine ServeurSuiv;
	IReseau reseau;
	Registry registryServeur;
	int nbrProc;
	ArrayList<IObserver> listOfObservers;
	String state;
	int couleurp;
	int mcp;
	boolean launchTerm; // true si la terminaison est lancé et false sinon

	private final static int MAX_PROC = 4;
	private final static int MIN_PROC = 2;

	/**
	 * Constructeur permettant de définir un serveur avec ses caractéristiques
	 * 
	 * @param nomServeur
	 * @param machine
	 * @param port
	 * @throws RemoteException
	 */
	public Serveur(String nomServeur, String machine, int port)
			throws RemoteException {
		super();
		listOfObservers = new ArrayList<IObserver>();
		this.machineServeur = new Machine(nomServeur, machine, port);
		nbrProc = (int) ((MAX_PROC - MIN_PROC) * Math.random()) + MIN_PROC;
		listeThreadServeur = new ThreadServeur[nbrProc];
		couleurp = Jeton.BLANC;
		mcp = 0;
		try {
			registryServeur = LocateRegistry.createRegistry(port);
			registryServeur.rebind(nomServeur, this);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		setLaunchTerm(false);
		System.out.println("Serveur ready !!!!" + nomServeur);

	}

	/**
	 * Constructeur permettant de définir un serveur avec ses caractéristiques
	 * (instance de l'Ihm serveur inclue)
	 * 
	 * @param nomServeur
	 * @param machine
	 * @param port
	 * @param ih
	 * @throws RemoteException
	 */
	public Serveur(String nomServeur, String machine, int port, Ihm_Serveur ih)
			throws RemoteException {
		this(nomServeur, machine, port);
		addObserver(ih); // A un serveur correspond une seule ihm
							// d'administration, ce qui permet de gerer ses log
	}

	/**
	 * getter de la machine serveur
	 * 
	 * @return machineServeur
	 */
	public Machine getMachineServeur() {
		return machineServeur;
	}

	/**
	 * getter de l'instance du réseau
	 * 
	 * @return reseau
	 */
	public IReseau getReseau() {
		return reseau;
	}

	/**
	 * Fonction permettant au serveur de se connecter à distance à la machine
	 * réseau
	 * 
	 * @param nomRes
	 *            : reference du réseau dans le registry
	 * @param machineRes
	 *            : adresse ip du réseau
	 * @param port
	 *            : port de connexion au réseau
	 * @return true si connexion reussie ou false sinon
	 */
	public boolean connectReseau(String nomRes, String machineRes, int port) {

		Registry regTmp;
		try {
			regTmp = LocateRegistry.getRegistry(machineRes, port);
			this.reseau = (IReseau) regTmp.lookup(nomRes);
			this.reseau.ping(machineServeur.machine);
			return true;
		} catch (RemoteException e) {
			state = new String(
					"Erreur(type RemoteException) lors de la tentative de connexion à la machine réseau");
			notifyObservers();
			e.printStackTrace();
			return false;
		} catch (NotBoundException e) {
			state = new String(
					"Erreur(type NotBoundException) lors de la tentative de connexion à la machine réseau");
			notifyObservers();
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Fonction permettant au serveur d'envoyer un jeton(de type traitement ou
	 * safra ou stop) à son successeur dans la topologie
	 */
	public void envoyerJeton(Jeton jt) {
		try {
			if (ServeurSuiv != null)
				reseau.envoiJetonSuiv(jt, ServeurSuiv);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Fonction invoquée à distance par le client ou le réseau pour transmettre
	 * un jeton(de type traitement ou safra ou stop) au serveur. Suivant le type
	 * de jeton en paramètre, un traitrement spécifique est déclenché par le
	 * serveur
	 * 
	 * @param jt
	 *            : jeton(de type traitement ou safra ou stop)
	 */
	public void recevoirJeton(Jeton jt) throws RemoteException {
		System.out.println("   Color :: mcp   " + couleurp + " :: " + mcp);
		synchronized (jt) {

			// cas où le jeton reçu est un jeton de type traitement
			if (jt instanceof JetonTraitement) {
				boolean first = false;

				System.out.println("decrementer:: "+((JetonTraitement) jt).emeteur);
				if (!((JetonTraitement) jt).emeteur.equals("client")){
					System.out.println("decrementer:: "+((JetonTraitement) jt).emeteur);
					decrementer();
				}
					

				((JetonTraitement) jt).setEmeteur("serveur");
				System.out.println("decrementer:: "+((JetonTraitement) jt).emeteur);

				if (reseau.getJeton(((JetonTraitement) jt).machineClient.nom) == null) {
					reseau.setJeton(jt);
					first = true;
				}

				// on ne décremente le compteur mCp que lors de la réception du
				// jeton de traitement de la part du serveur précedent
				// et non lors de lors de la réception du jeton de la part du
				// client (cas de la première réception)

				// on met un verrou sur le jeton encours de traitement pour
				// éviter que plusieurs serveurs ne le modifie simultanément
				// rappelons qu'un traitement d'un client n'est géré que par un
				// seul jeton et celui est référencé sur le réseau
				synchronized (reseau.getJeton(((JetonTraitement) jt).machineClient.nom)) {

					// on parcourt les threads du serveur et on en fonction de
					// leur disponiblité, on leur attribue un traitement à
					// effectuer ou non
					for (int i = 0; i < listeThreadServeur.length; i++) {

						// il reste des portions à traiter et la thread est
						// libre
						if (((JetonTraitement) reseau
								.getJeton(((JetonTraitement) jt).machineClient.nom)).pi >= 0
								&& (listeThreadServeur[i] == null || !listeThreadServeur[i].actif)) {

							state = new String(
									"Reception jeton numero "
											+ ((JetonTraitement) reseau
													.getJeton(((JetonTraitement) jt).machineClient.nom)).pi
											+ " du client("
											+ ((JetonTraitement) reseau
													.getJeton(((JetonTraitement) jt).machineClient.nom)).machineClient.nom
											+ ") pour traitement("
											+ TypeTraitement
													.getDetailTraitement(((JetonTraitement) reseau
															.getJeton(((JetonTraitement) jt).machineClient.nom)).typeT
															.getFiltre()) + ")");

							notifyObservers();
							listeThreadServeur[i] = new ThreadServeur(
									listOfObservers.get(0),
									((JetonTraitement) reseau
											.getJeton(((JetonTraitement) jt).machineClient.nom)));
							reseau
									.setJetonPi(
											((JetonTraitement) jt).machineClient.nom,
											(((JetonTraitement) reseau
													.getJeton(((JetonTraitement) jt).machineClient.nom)).pi - 1));
							listeThreadServeur[i].start();

						}
						// il ne reste plus de portion à traiter
						else if (((JetonTraitement) reseau
								.getJeton(((JetonTraitement) jt).machineClient.nom)).pi < 0)
							break;
					}

					// il reste des portions à traiter et il existe un serveur
					// suivant dans la topologie
					if (((JetonTraitement) reseau
							.getJeton(((JetonTraitement) jt).machineClient.nom)).pi >= 0
							&& ServeurSuiv != null) {
						try {
							// on incremente le compteur mCp puis on transmet le
							// jeton au réseau qui se chargera de le transmettre
							// au serveur suivant
							incrementer();
							envoyerJeton(reseau
									.getJeton(((JetonTraitement) jt).machineClient.nom));
						} catch (RemoteException e) {
							e.printStackTrace();
						}
					}

					// il reste des portions à traiter mais le serveur est
					// unique et ne possède pas de serveur suivant dans la
					// topologie
					else if (((JetonTraitement) reseau
							.getJeton(((JetonTraitement) jt).machineClient.nom)).pi >= 0) {
						// on fait un sleep pour attendre un peu puis on renvoie
						// le jeton à l'instance de serveur encours par le
						// réseau
						// l'instance de serveur encours est considéré ici comme
						// étant son propre serveur suivant
						try {
							Thread.sleep(50);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
						try {
							// on incremente le compteur mCp puis on transmet le
							// jeton au réseau qui se chargera de le
							// retransmettre
							// à l'instance de serveur encours
							incrementer();
							reseau
									.envoiJetonSuiv(
											reseau
													.getJeton(((JetonTraitement) jt).machineClient.nom),
											machineServeur);
						} catch (RemoteException e) {
							e.printStackTrace();
						}

					}
				}

			}

			// cas où le jeton reçu est un jeton de type Safra
			else if (jt instanceof JetonSafra) {

				if (!isLaunchTerm())
					setLaunchTerm(true);

				// lancement de la terminaison
				safra((JetonSafra) jt);

			}

			// cas où le jeton reçu est un jeton de type Stop
			else if (jt instanceof JetonStop) {
				System.out.println(machineServeur.nom + " a recu STop");
				// lancement de l'arrêt des serveurs
				stop((JetonStop) jt);
			}
		}
	}

	/**
	 * Fonction permettant de lancer la détection de la terminaison des serveurs
	 * ainsi que leur arrêt
	 * 
	 * @param jt
	 *            : de type Safra
	 */
	public void safra(JetonSafra jt) {

		// si le serveur principal est non défini alors on défini l'instance de
		// serveur encours comme serveur N°0
		if (jt.ServeurP0.equals(""))
			jt.ServeurP0 = new String(machineServeur.nom);

		// si l'instance de serveur encours est le serveur N°0
		if (jt.ServeurP0.equals(machineServeur.nom)) {

			// si les conditions d'arrêt sont réunis, alors on lance la
			// terminaison de tous les serveurs à l'aide du jeton Stop
			if (jt.c == Jeton.BLANC && couleurp == Jeton.BLANC
					&& ((mcp + jt.compteur) == 0)) {
				JetonStop jts = new JetonStop();
				jts.ServeurP0 = new String(machineServeur.nom);
				state = new String(
						"Serveur prinicpal: lancement du processus d'arrêt de tous les serveurs...");
				notifyObservers();
				System.out.println("serveur arret.....");
				stop(jts);
			}

			// si les conditions d'arrêt ne sont pas réunis, alors on lance une
			// nouvelle vague de détection de la terminaison
			else {
				state = new String(
						"Serveur prinicpal: détection terminaison infructueuse, lancement d'une nouvelle vague...");
				notifyObservers();
				System.out.println("reset Wave, ct.compteur=0");
				jt.c = Jeton.BLANC;
				jt.compteur = 0;
				envoyerJeton(jt);
			}
		}

		// si l'instance de serveur encours n'est pas le serveur N°0
		else {
			System.out.println("process secondaire, mcp + jt.compteur="
					+ (mcp + jt.compteur));
			if (jt.c == Jeton.BLANC) {
				jt.compteur += mcp;
				envoyerJeton(jt);
			} else {
				jt.c = Jeton.NOIR;
				jt.compteur += mcp;
				envoyerJeton(jt);
			}
		}
		couleurp = Jeton.BLANC;
	}

	/**
	 * Fonction permettant d'arrêter les serveurs. L'arrêt ici se traduit par le
	 * déréférencement du serveur dans le registry
	 * 
	 * @param jt
	 *            : type Stop
	 */
	private void stop(JetonStop jt) {

		try {
			setLaunchTerm(true);
			registryServeur.unbind(machineServeur.nom);
			state = new String("Serveur arrêté...");
			notifyObservers();

			if (!jt.ServeurP0.equals(getServeurSuiv().nom)) {
				envoyerJeton(jt);
			} else {
				state = new String(
						"L'arrêt de tous les serveurs s'est effectué avec succès...");
				notifyObservers();
			}

			System.out.println("server stoped " + machineServeur.nom);

		} catch (RemoteException e) {
			state = new String(
					"Erreur(type RemoteException) lors de l'envoi du jeton Stop...");
			notifyObservers();
		} catch (NotBoundException e) {
			state = new String(
					"Erreur(type NotBoundException) lors de l'envoi du jeton Stop...");
			notifyObservers();
		}
	}

	/**
	 * Méthode permettant d'incrémenter le compteur mCp du serveur
	 */
	public void incrementer() {
		mcp++;
	}

	/**
	 * Méthode permettant de décrémenter le compteur mCp du serveur
	 */
	public void decrementer() {
		mcp--;
	}

	/**
	 * Getter de la machine dont le serveur effectue le traitement
	 * 
	 * @return clientTraite
	 */
	public Machine getClientTraite() {
		return clientTraite;
	}

	/**
	 * Setter de la machine dont le serveur effectue le traitement
	 */
	public void setClientTraite(Machine clientTraite) {
		this.clientTraite = clientTraite;
	}

	/**
	 * Getter de la liste des threads du serveur
	 * 
	 * @return listeThreadServeur
	 */
	public ThreadServeur[] getListeThreadServeur() {
		return listeThreadServeur;
	}

	/**
	 * Setter de la liste des threads du serveur
	 */
	public void setListeThreadServeur(ThreadServeur[] threadServeur) {
		listeThreadServeur = threadServeur;
	}

	/**
	 * Getter du serveur suivant de l'instance de serveur encours
	 * 
	 * @return ServeurSuiv
	 */
	public Machine getServeurSuiv() {
		return ServeurSuiv;
	}

	/**
	 * Setter du serveur suivant de l'instance de serveur encours
	 */
	public void setServeurSuiv(Machine serveurSuiv) {
		ServeurSuiv = serveurSuiv;
	}

	/**
	 * setter de lanchter
	 * 
	 * @param launchTerm
	 */
	public void setLaunchTerm(boolean launchTerm) {
		this.launchTerm = launchTerm;
	}

	/**
	 * @return true si terminaison lancé et false sinon
	 */
	public boolean isLaunchTerm() {
		return launchTerm;
	}

	/**
	 * Getter du nombre de threads du serveur
	 * 
	 * @return nbrProc
	 */
	public int getNbrProc() {
		return nbrProc;
	}

	/**
	 * Setter du nombre de threads du serveur
	 */
	public void setNbrProc(int nbrProc) {
		this.nbrProc = nbrProc;
	}

	/**
	 * Setter de la machine serveur
	 */
	public void setMachineServeur(Machine machineServeur) {
		this.machineServeur = machineServeur;
	}

	/**
	 * Setter de la machine réseau
	 */
	public void setReseau(IReseau reseau) {
		this.reseau = reseau;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see pack.IObservable#addObserver(pack.IObserver)
	 */
	@Override
	public void addObserver(IObserver o) {
		listOfObservers.add(o);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see pack.IObservable#notifyObservers()
	 */
	@Override
	public void notifyObservers() {
		if (!state.equals(new String("")))
			for (IObserver o : listOfObservers) {
				o.updateLog(this, state);
			}
		state = new String("");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see pack.IObservable#removeObserver(pack.IObserver)
	 */
	@Override
	public void removeObserver(IObserver o) {
		listOfObservers.remove(o);
	}

	/**
	 * Fonction invoquée à distance par le client pour tester sa connexion au
	 * serveur
	 */
	@Override
	public void ping(String nomClient) throws RemoteException {
		state = new String("Connexion du client " + nomClient);
		notifyObservers();

	}

}
