package traitement_image;



/**
 * Classe utilitaire permettant d'appliquer le filtre Niveau de Gris sur une image ou une portion d'image
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class NiveauxGris{


	public static int[] filtrerImage(int width, int height, int[] srcPixels) {

		int dstPixels[] = new int[srcPixels.length];

		for(int X=0; X<srcPixels.length; X++)  {
			int r = 0, g = 0, b = 0; 
			int moy = 0;
			r = (int)getRed(srcPixels[X]);
			g = (int)getGreen(srcPixels[X]);
			b = (int)getBlue(srcPixels[X]);

			moy = (r + g + b) / 3;

			int newRGB = (0xff << 24) + (moy << 16) + (moy << 8) + (moy);
			dstPixels[X] = newRGB;
		}

		return dstPixels;
	}

	public static int getRed(int pixel) {
		int tmp = pixel & 0x00FF0000;
		return tmp >> 16;
	}
	public static int getGreen(int pixel) {
		int tmp = pixel & 0x0000FF00;
		return tmp >> 8;
	}
	public static int getBlue(int pixel) {
		int tmp = pixel & 0x000000FF;
		return tmp;
	}

}
