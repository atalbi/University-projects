package pack;

/**
 * Interface définissant les méthodes accessibles aux observateurs (pattern Observer),  ici les IHM
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public interface IObserver {

	void updateLog(IObservable o, String info);

}
