package client;

import ihm.client.Ihm;

import java.awt.Cursor;
import java.rmi.RemoteException;

import jeton.JetonTraitement;
import traitement_image.Portion_Image;
import traitement_image.TypeTraitement;


/**
 * Thread permettant de lancer le traitement client sur le serveur
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class ThreadClient extends Thread {

	TypeTraitement typeT;
	Client client;
	
	public ThreadClient(Client client, TypeTraitement typeT) {
		this.typeT = typeT;
		this.client = client;
		
	}


	public void run () {
		synchronized(this){
			client.resultat = new Portion_Image[Ihm.nbPortion];

			for (Portion_Image p: client.resultat)
				p = null;

			client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

			//creation du jeton de traitement
			JetonTraitement jt = new JetonTraitement(client.machineClient, client.pi.length-1, typeT,"client");
			
			try {

				client.getServeur().recevoirJeton(jt); //envoi du jeton au serveur
				
			} catch (RemoteException e) {
				client.state = new String("Erreur(type: RemoteException) de communication avec le serveur lors de l'envoi du jeton "+jt.pi);
				client.notifyObservers();
				client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				e.printStackTrace();
			}

			client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		}
	}
}
