package ihm.client;

import java.io.IOException;

/**
 * Classe de lancement de l'Ihm client
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Launcher {

	public static void main(String[] args) throws IOException {

		new Ihm(".:AD PROJECT:.");
	}

}
