package traitement_image;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

/**
 * Classe définissant les caractériques d'une image chargée
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class MyImage implements Serializable {

	private static final long serialVersionUID = 1L;
	private int srcImage[];
	private int width;
	private int height;

	public MyImage(String img) throws IOException, InterruptedException {
		BufferedImage imageBuffered = ImageIO.read(new java.io.File(img));
		width = imageBuffered.getWidth();
		height = imageBuffered.getHeight();
		srcImage = imageBuffered.getRGB(0, 0, width, height, null, 0, width);
	}

	public BufferedImage getImageBuffered() throws IOException {
		BufferedImage dst = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);
		dst.setRGB(0, 0, width, height, srcImage, 0, width);
		return dst;
	}


	public int[] getSrcImage() {
		return srcImage;
	}

	public void setSrcImage(int[] srcImage) {
		for(int i=0;i<srcImage.length;i++)
			this.srcImage[i] = srcImage[i];
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

}
