package ihm.client;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.Inet4Address;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import client.Client;

/**
 * IHM permettant au client de configurer les paramètres réseaux
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Parametre_Client extends JDialog{

	private static final long serialVersionUID = 1L;
	JPanel jp, jp1, jp2;
	JLabel lab1, lab2, lab3;
	JButton add, cancel;
	Ihm ih;
	private JTextField portClient, adresseClient, nomClient;


	public Ihm_Parametre_Client(Ihm ih) {
		this.ih = ih;
		setTitle("Parametrage Client...");
		this.setModal(true);
		init();

	}


	private void init(){

		this.setSize(new Dimension(300,170));
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		jp = new JPanel();
		GridLayout grid = new GridLayout(3,2);
		grid.setVgap(3);
		BoxLayout box = new BoxLayout(jp, BoxLayout.Y_AXIS);
		jp.setLayout(box);
		jp1 = new JPanel();
		jp1.setLayout(grid);
		lab1 = new JLabel("Nom machine client  ");
		nomClient = new JTextField();
		nomClient.setText("Machine_Client");
		lab2 = new JLabel("Adresse machine client");
		adresseClient = new JTextField();
		try {
			adresseClient.setText(Inet4Address.getLocalHost().getHostName());
		} catch (UnknownHostException e) {e.printStackTrace();}
		lab3 = new JLabel("Port machine client");
		portClient = new JTextField();
		portClient.setText("9000");
		jp1.add(lab1);
		jp1.add(nomClient);
		jp1.add(lab2);
		jp1.add(adresseClient);
		jp1.add(lab3);
		jp1.add(portClient);

		add = new JButton("Valider");
		add.setActionCommand("btnValider");
		add.addActionListener(new Ecouteur());
		jp2 = new JPanel();
		cancel = new JButton("Annuler");
		cancel.setActionCommand("btnAnnuler");
		cancel.addActionListener(new Ecouteur());

		jp.add(new JLabel(" "));
		jp.add(jp1);
		jp2.add(add);
		jp2.add(cancel);
		jp.add(jp2);
		this.add(jp);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});
		setVisible(true);
	}


	class Ecouteur implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			if (arg0.getActionCommand().equals("btnValider")){
				if (!Ihm_Parametre_Client.this.nomClient.getText().equals("") && 
						!Ihm_Parametre_Client.this.adresseClient.getText().equals("") && 
						!Ihm_Parametre_Client.this.portClient.getText().equals("")){

					Client clt;
					String nom = Ihm_Parametre_Client.this.nomClient.getText();
					String adresse = Ihm_Parametre_Client.this.adresseClient.getText();
					int port = 0;
					try {
						port = Integer.parseInt(Ihm_Parametre_Client.this.portClient.getText()); 
					}
					catch (NumberFormatException e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(Ihm_Parametre_Client.this, "Erreur sur le format du numero de port saisi !", 
								"Erreur", JOptionPane.ERROR_MESSAGE);
						Ihm_Parametre_Client.this.ih.log.append("\n> Erreur sur le format du numero de port saisi pour le client");
					}
					try {
						clt = new Client(nom, adresse, port, ih);
						Ihm_Parametre_Client.this.ih.setClient(clt);
						Ihm_Parametre_Client.this.ih.log.append("\n> Parametres réseaux(Nom: "+nom+", adresse: "+adresse+
								", port:"+port+") du client configurés avec succès");
						Ihm_Parametre_Client.this.dispose();

					}catch (RemoteException e) {
						e.printStackTrace();
					} catch (MalformedURLException e) {
						e.printStackTrace();
					} catch (NotBoundException e) {
						e.printStackTrace();
					}


				}
			}
			else if (arg0.getActionCommand().equals("btnAnnuler")){
				if (!Ihm_Parametre_Client.this.nomClient.getText().equals("") || 
						!Ihm_Parametre_Client.this.adresseClient.getText().equals("") ||
						!Ihm_Parametre_Client.this.portClient.getText().equals("")){
					Ihm_Parametre_Client.this.nomClient.setText(""); 
					Ihm_Parametre_Client.this.adresseClient.setText(""); 
					Ihm_Parametre_Client.this.portClient.setText("");
				}
				else {
					Ihm_Parametre_Client.this.dispose();
				}
			}

		}

	}
}

