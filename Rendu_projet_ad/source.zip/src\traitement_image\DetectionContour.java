package traitement_image;

/**
 * Classe utilitaire permettant d'appliquer le filtre Détection de contour sur une image ou une portion d'image
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class DetectionContour{


	public static int[] filtrerImage(int width, int height, int srcPixels[]) {

		int GX[][] = new int[3][3];
		int GY[][] = new int[3][3];
		GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
		GX[1][0] = -2; GX[1][1] = 0; GX[1][2] = 2;
		GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;
		GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
		GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
		GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;
		int dstPixels[] = new int[srcPixels.length];
		
		for(int Y=0; Y<height; Y++)  {
			for(int X=0; X<width; X++)  {
				int red = 0, green = 0, blue = 0; 
				int I, J;
				int redSumX = 0, greenSumX = 0, blueSumX = 0;
				int redSumY = 0, greenSumY = 0, blueSumY = 0;;

				if(Y==0 || Y==height-1) {
					red = 0;
					green = 0;
					blue = 0;
				}
				else if(X==0 || X==width-1) {
					red = 0;
					green = 0;
					blue = 0;
				}
				else   {
					for(I=-1; I<=1; I++)
						for(J=-1; J<=1; J++) {
							redSumX += (int)(getRed(srcPixels[X + I + (Y + J) * width]) * GX[I+1][J+1]);
							greenSumX += (int)(getGreen(srcPixels[X + I + (Y + J) * width]) * GX[I+1][J+1]);
							blueSumX += (int)(getBlue(srcPixels[X + I + (Y + J) * width]) * GX[I+1][J+1]);
						}

					for(I=-1; I<=1; I++)
						for(J=-1; J<=1; J++) {
							redSumY += (int)(getRed(srcPixels[X + I + (Y + J) * width]) * GY[I+1][J+1]);
							greenSumY += (int)(getGreen(srcPixels[X + I + (Y + J) * width]) * GY[I+1][J+1]);
							blueSumY += (int)(getBlue(srcPixels[X + I + (Y + J) * width]) * GY[I+1][J+1]);
						}

					red = Math.abs(redSumX) + Math.abs(redSumY);
					green = Math.abs(greenSumX) + Math.abs(greenSumY);
					blue = Math.abs(blueSumX) + Math.abs(blueSumY);
				}

				if(red>255)
					red=255;
				if(red<0)
					red=0;
				if(green>255)
					green=255;
				if(green<0)
					green=0;
				if(blue>255)
					blue=255;
				if(blue<0)
					blue=0;

				red = 255 - red;
				green = 255 - green;
				blue = 255 - blue;

				dstPixels[X + Y * width] = 0xFF000000 | (red << 16) | (green << 8) | blue;
			}
		}
		return dstPixels;
	}
	
	public static int getRed(int pixel) {
		int tmp = pixel & 0x00FF0000;
		return tmp >> 16;
	}
	
	public static int getGreen(int pixel) {
		int tmp = pixel & 0x0000FF00;
		return tmp >> 8;
	}
	
	public static int getBlue(int pixel) {
		int tmp = pixel & 0x000000FF;
		return tmp;
	}
	
}
