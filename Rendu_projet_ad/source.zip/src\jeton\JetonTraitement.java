package jeton;

import pack.Machine;
import traitement_image.TypeTraitement;



/**
 * Classe définissant les caractéristiques d'un jeton de traitement(jeton utilisé dans
 *  le cadre du partage du travail du traitement des portions d'images)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class JetonTraitement extends Jeton {

	private static final long serialVersionUID = 1L;
	public Machine machineClient;
	public int pi;
	public TypeTraitement typeT;
	public String emeteur;
	
	
	public JetonTraitement(Machine machineClient, int pi,String emeteur) {
		super(null);
		this.machineClient = machineClient;
		this.pi = pi;
		this.emeteur=emeteur;
	}
	
	public JetonTraitement(Machine machineClient, int pi, TypeTraitement typeT,String emeteur) {
		super(null);
		this.machineClient = machineClient;
		this.pi = pi;
		this.typeT = typeT;
		this.emeteur=emeteur;
	}
	
	public void setPi(int pi) {
		this.pi = pi;
	}

	public void setEmeteur(String emeteur) {
		this.emeteur=emeteur;
		
	}

}
