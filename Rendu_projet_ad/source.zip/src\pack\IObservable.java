package pack;

/**
 * Interface définissant les méthodes accessibles aux objets observés (pattern Observer),  ici le serveur, le client,...
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public interface IObservable {
	void addObserver(IObserver o);
	void removeObserver(IObserver o);
	void notifyObservers();

}
