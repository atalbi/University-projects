package serveur;

import ihm.server.Ihm_Serveur;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

import jeton.*;
import traitement_image.*;
import client.*;
import pack.*;

/**
 * Thread permettant au serveur de gérer de façon parallèle le traitement de deux portions d'images
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class ThreadServeur extends Thread implements IObservable{

	boolean actif;
	JetonTraitement jeton;
	IClient clientTraite;
	ArrayList<IObserver> listOfObservers;
	String state;

	/**
	 * Constructeur
	 */
	public ThreadServeur() {
		super();
		actif = false;
		listOfObservers = new ArrayList<IObserver>();
	}

	/**
	 * Constructeur
	 * @param o
	 * @param j
	 */
	public ThreadServeur(IObserver o, JetonTraitement j){
		this();
		addObserver(o);
		this.jeton = j;
	}


	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run() {

		try {
			actif = true;
			state = new String("Lancement traitement(client '"+jeton.machineClient.nom+"', filtre '"+
					TypeTraitement.getDetailTraitement(jeton.typeT.getFiltre())+"', jeton "+jeton.pi+")");
			notifyObservers();
			Registry regTmp = LocateRegistry.getRegistry(jeton.machineClient.machine, jeton.machineClient.port);
			this.clientTraite = (IClient) regTmp.lookup(jeton.machineClient.nom);
			System.out.println("portion a recup pour TRAITEMENT"+jeton.pi);
			Portion_Image partieImg = clientTraite.getPi(jeton.pi);
			partieImg.setPixel(traitrement(partieImg, jeton.typeT));

			clientTraite.accepterPartieImage(partieImg);
			actif = false;
			state = new String("Fin traitement jeton "+jeton.pi+", resultat envoyé au client");
			notifyObservers();
			if (listOfObservers.get(0) instanceof Ihm_Serveur) {
				if (((Ihm_Serveur)listOfObservers.get(0)).getServeur().reseau.getJeton(jeton.machineClient.nom) != null){
					synchronized (((Ihm_Serveur)listOfObservers.get(0)).getServeur().reseau.getJeton(jeton.machineClient.nom)) {
						if (((JetonTraitement)((Ihm_Serveur)listOfObservers.get(0)).getServeur().reseau.getJeton(jeton.machineClient.nom)).pi == -1) {

							((Ihm_Serveur)listOfObservers.get(0)).getServeur().reseau.deleteJeton(jeton.machineClient.nom);
							state = new String("Requete client traitée à 100% ");
							notifyObservers();

						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Fonction de traitement proprement dit de la portion d'image reçu du client 
	 * @param portion : portion d'image reçu
	 * @param typeT : type de filtre à appliquer sur l'image
	 * @return resultat
	 */
	int[] traitrement (Portion_Image portion, TypeTraitement typeT) {

		int[] resultat = null;
		switch (typeT.getFiltre()) {

		case 1:
			resultat = NiveauxGris.filtrerImage(portion.getLargeur(), portion.getHauteur(),portion.getPixel());
			break;

		case 2:
			resultat = Saturation.filtrerImage(portion.getLargeur(), portion.getHauteur(),portion.getPixel());
			break;

		case 3:
			resultat = DetectionContour.filtrerImage(portion.getLargeur(), portion.getHauteur(),portion.getPixel());
			break;

		case 4:
			resultat = RVB.filtrerImage(portion.getLargeur(), portion.getHauteur(),portion.getPixel(), typeT.isR(), typeT.isV(), typeT.isB());
			break;

		}

		return resultat;
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#addObserver(pack.IObserver)
	 */
	@Override
	public void addObserver(IObserver o) {
		listOfObservers.add(o);		
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#notifyObservers()
	 */
	@Override
	public void notifyObservers() {
		if (!state.equals(new String("")))
			for (IObserver o: listOfObservers){
				o.updateLog(this, state);
			}
		state = new String("");
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#removeObserver(pack.IObserver)
	 */
	@Override
	public void removeObserver(IObserver o) {
		listOfObservers.remove(o);		
	}
}
