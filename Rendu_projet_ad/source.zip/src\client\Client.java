package client;

import ihm.client.Ihm;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import jeton.JetonTraitement;
import pack.IObservable;
import pack.IObserver;
import pack.Machine;
import serveur.IServeur;
import traitement_image.MyImage;
import traitement_image.Portion_Image;
import traitement_image.TypeTraitement;

/**
 * Classe definissant toutes les informations relatives à un client ainsi que les fonctions
 * accessibles à celui-ci (connexion à un serveur, demande de traitement, demande de terminaison, etc)
 * @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Client extends UnicastRemoteObject implements IClient, IObservable {

	private static final long serialVersionUID = 1L;
	private IServeur serveur;
	public Machine machineClient;
	public Machine machineServeur;
	MyImage image;
	Registry registryClient;
	public Portion_Image[] pi;
	Ihm ih;
	Portion_Image[] resultat;
	ArrayList<IObserver> listOfObservers;
	String state;

	/* (non-Javadoc)
	 * @see client.IClient#getPi(int)
	 */
	public Portion_Image getPi(int i) {
		return pi[i];
	}

	/**
	 * Construction principal permettant de definir un client avec tous ses parametres
	 * @param nomClient : reference du client dans le registry
	 * @param machineClient : adresse ip du client
	 * @param port : port du client
	 * @param ih : instance de l'Ihm client
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws NotBoundException
	 */
	public Client(String nomClient, String machineClient, int port, Ihm ih) throws RemoteException, MalformedURLException, NotBoundException {
		super();
		listOfObservers = new ArrayList<IObserver>();
		setIh(ih);
		this.machineClient = new Machine(nomClient, machineClient, port);
		try {
			registryClient=LocateRegistry.createRegistry(port);
			registryClient.rebind(nomClient, this);
			System.out.println("Client ready!!!!");
			System.out.println("Client " + this.machineClient.nom
					+ " crée avec nom de machine :: " + this.machineClient.machine
					+ " et N° de port :: " + this.machineClient.port);
		} catch (RemoteException e) {
			state = new String("Erreur(type: RemoteException) lors de la creation du client dans le registry");
			notifyObservers();
			e.printStackTrace();
		}
	}



	/* fonction permettant au client de créer un jeton et de lancer le traitement à distance sur le serveur 
	 * @param typeFiltre : type de traitement à lancer
	 * @param r : (rouge, utilisépour le filtre RVB) 
	 * @param v : (vert, utilisé pour le filtre RVB)
	 * @param b : (bleu, utilisé pour le filtre RVB) 
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws NotBoundException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void demandeTraitement(int typeFiltre, boolean r, boolean v, boolean b)  {
		System.out.println("Client " + machineClient.nom+ " :: Demande traitement");


		try {
			Registry regTmp = LocateRegistry.getRegistry(machineServeur.machine,machineServeur.port);
			serveur = (IServeur) regTmp.lookup(machineServeur.nom);

			this.ih.pixelPrec = this.ih.getImageLoadBuff().getRGB(0, 0, this.ih.getClient().getImage().getWidth(), this.ih.getClient().getImage().getHeight(),
					this.ih.pixelPrec, 0, this.ih.getClient().getImage().getWidth());

			// cas ou le serveur connu du client possede un successeur dans la topologie
			if (getServeur().getServeurSuiv() != null) {
				if (!getServeur().isLaunchTerm()) {
					state = new String("Creation de "+pi.length+" jetons de traitements pour soumission au serveur " +getServeur().getMachineServeur().machine);
					notifyObservers();
					ThreadClient th = new ThreadClient(this, new TypeTraitement(typeFiltre, r, v, b));
					th.start();
				}
				else {
					state = new String("Impossible de lancer un nouveau traitement car un processus de terminaison est encours sur le serveur");
					notifyObservers();
				}
			}

			// cas ou le serveur connu du client est unique et donc seul pour le traitement
			else {
				if (!getServeur().isLaunchTerm()) {
					resultat = new Portion_Image[1];
					resultat[0] = null;
					pi = new Portion_Image[1];
					pi[0] = new Portion_Image();
					pi[0].setLargeur(image.getWidth());
					pi[0].setHauteur(image.getHeight());
					pi[0].setDebutX(0);
					pi[0].setDebutY(0);
					pi[0].setPixel(image.getSrcImage());
					pi[0].setOrdre(0);
					JetonTraitement jt = new JetonTraitement(machineClient, 0, new TypeTraitement(typeFiltre, r, v, b),new String("client"));
					state = new String("Creation de "+pi.length+" jeton de traitements pour soumission au serveur " +getServeur().getMachineServeur().machine);
					notifyObservers();
					getServeur().recevoirJeton(jt);
				}
				else {
					state = new String("Impossible de lancer un nouveau traitement car un processus de terminaison est encours sur le serveur");
					notifyObservers();
				}
			}
		} catch (RemoteException e) {
			state = new String("Erreur(type: RemoteException) de communication avec le serveur");
			notifyObservers();
			e.printStackTrace();
		} catch (NotBoundException e) {
			state = new String("Erreur(type: NotBoundException) de communication avec le serveur");
			notifyObservers();
			e.printStackTrace();
		}
	}

	/**
	 * fonction permettant à un client de se connecter a un serveur distant
	 * @param nomServeur : reference du serveur dans le registry
	 * @param machineServeur : adresse ip du serveur
	 * @param port : port de connexion au serveur
	 * @return true si connexion reussie et false sinon
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws NotBoundException
	 */
	public  boolean connectServeur(String nomServeur, String machineServeur, int port) {
		this.machineServeur = new Machine(nomServeur, machineServeur, port);
		Registry regTmp;
		try {
			regTmp = LocateRegistry.getRegistry(machineServeur, port);
			this.setServeur((IServeur)regTmp.lookup(nomServeur));
			state = new String("Succès de la conexion au serveur(Nom: "+nomServeur+", adresse: "+machineServeur+", port: "+port+") ");
			notifyObservers();
			getServeur().ping(machineClient.machine);
			ih.activeStop();
			System.out.println("Client " + machineClient.nom+ " :: Connecté au serveur " + getServeur().getMachineServeur().nom);
		} catch (RemoteException e) {
			e.printStackTrace();
			state = new String("Erreur(type RemoteException) lors de la connexion au serveur(Nom: "+nomServeur+", adresse: "+machineServeur+", port: "+port+") ");
			notifyObservers();
			return false;
		} catch (NotBoundException e) {
			state = new String("Erreur(type NotBoundException) lors de la connexion au serveur(Nom: "+nomServeur+", adresse: "+machineServeur+", port: "+port+") ");
			notifyObservers();
			e.printStackTrace();
			return false;
		}		

		return true;
	}

	/**
	 * fonction permettant au  client de lancer le processus de terminaison des serveurs
	 */
	public void demandeTerminaison(){

		Registry regTmp;
		try {
			regTmp = LocateRegistry.getRegistry(machineServeur.machine,machineServeur.port);
			serveur = (IServeur) regTmp.lookup(machineServeur.nom);
			ih.activeStop();
			new ThreadSafra(this, serveur).start();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}

	}

	/**
	 * fonction permettant d'associer une image à traiter à un client
	 * @param image
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void setImage(String image) throws IOException, InterruptedException {
		this.image = new MyImage(image);
		System.out.println("Client " + machineClient.nom + " :: Image chargée");
	}

	/**
	 * fonction permettant au client de recuperer le resultat des traitements effectués sur les serveurs.
	 * cette methode est invoquee par les serveurs a distance 
	 * @param partieImg : portion d'image traitee
	 * @throws RemoteException
	 * @throws IOException
	 */
	public void accepterPartieImage(Portion_Image partieImg) throws IOException {
		synchronized(this.ih.getImageLoadBuff())  {
			resultat[partieImg.getOrdre()] = partieImg;
			if (this.ih != null){
				if (partieImg.getOrdre() == 0) {
					this.ih.activePrecedent();
					this.ih.desactiveSuivant();
				}

				this.ih.getImageLoadBuff().setRGB(partieImg.getDebutX(), partieImg.getDebutY(), partieImg.getLargeur(),
						partieImg.getHauteur(), partieImg.getPixel(), 0, partieImg.getLargeur());

			}
			state = new String("1Reception resultat traitement: portion "+partieImg.getOrdre());
			notifyObservers();

		}
	}

	/**
	 * fonction permettant de recuperer l'instance de l'image chargee 
	 * @return image
	 * @throws RemoteException
	 */
	public MyImage getImage() throws RemoteException {
		return image;
	}

	/**
	 * setter de l'Ihm client
	 * @param ih
	 */
	public void setIh(Ihm ih) {
		this.ih = ih;
		addObserver(ih);
	}

	/**
	 * getterde l'Ihm client
	 * @return ih
	 */
	public Ihm getIh() {
		return ih;
	}

	/**
	 * setter de l'instance de serveur connu du client
	 * @param serveur
	 */
	public void setServeur(IServeur serveur) {
		this.serveur = serveur;
	}

	/**
	 * getter de l'instance de serveur connu du client
	 * @return serveur
	 */
	public IServeur getServeur() {
		return serveur;
	}

	/* (non-Javadoc)
	 * @see pack.IObservable#addObserver(pack.IObserver)
	 */
	@Override
	public void addObserver(IObserver o) {
		listOfObservers.add(o);		
	}


	/* 
	 * fonction permettant de notifier dans l'Ihm, l'etat d'evolution des traitement
	 */
	@Override
	public void notifyObservers() {

		if (!state.equals(new String("")))

			for (IObserver o: listOfObservers){
				o.updateLog(this, state);
			}
		state = new String("");
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#removeObserver(pack.IObserver)
	 */
	@Override
	public void removeObserver(IObserver o) {
		listOfObservers.remove(o);		
	}

}
