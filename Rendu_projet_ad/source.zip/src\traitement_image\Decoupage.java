package traitement_image;

import ihm.client.Ihm;

import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Classe utilitaire permettant le découpage de l'image initiale en plusieurs portions d'images
 * à utiliser par les serveurs pour le traitement 
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Decoupage {

	public Portion_Image tableauPortion[];

	
	/**
	 * Methode de découpage
	 * @param image
	 * @return tableauPortion
	 */
	public Portion_Image[] decoupe(MyImage image) {
		BufferedImage buf = null;
		try {
			buf = image.getImageBuffered();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		int width = image.getWidth();
		int height = image.getHeight();
		Ihm.log(" > Dimension initiale ("+width+","+height+")");
		Ihm.log(" > Decoupage");

		int divX, divY;
		divY = 2;
		divX = (Ihm.nbPortion%divY == 0)? Ihm.nbPortion/divY : Ihm.nbPortion/divY + 1;
		int ind = 0;
		Ihm.nbPortion = divY*divX;
		tableauPortion = new Portion_Image[Ihm.nbPortion];

		for (int j=0; j<divY; j++) {
			for (int i=0; i<divX; i++) {

				if (i==0 && j==0) {
					tableauPortion[ind] = new Portion_Image();
					tableauPortion[ind].ordre = ind;
					tableauPortion[ind].debutX = 0;
					tableauPortion[ind].debutY = 0;
					tableauPortion[ind].largeur = (width%divX == 0)? width/divX : width/divX + width%divX;
					tableauPortion[ind].hauteur = (height%divY == 0)? height/divY : height/divY + height%divY;
					tableauPortion[ind].setPixel(new int[tableauPortion[0].largeur*tableauPortion[0].hauteur]);
				}
				else { 
					tableauPortion[ind] = new Portion_Image();
					if(i == 0){
						tableauPortion[ind].ordre = ind;
						tableauPortion[ind].debutX = 0;
						tableauPortion[ind].debutY = tableauPortion[ind-1].debutY+tableauPortion[ind-1].hauteur;
						tableauPortion[ind].largeur = (width%divX == 0)? width/divX : width/divX + width%divX;
						tableauPortion[ind].hauteur = height/divY;
						tableauPortion[ind].setPixel(new int[tableauPortion[ind].largeur*tableauPortion[ind].hauteur]);
					}
					else if(j == 0){
						tableauPortion[ind].ordre = ind;
						tableauPortion[ind].debutX = tableauPortion[ind-1].debutX + tableauPortion[ind-1].largeur;
						tableauPortion[ind].debutY = 0;
						tableauPortion[ind].largeur = width/divX;
						tableauPortion[ind].hauteur = (height%divY == 0)? height/divY : height/divY + height%divY;
						tableauPortion[ind].setPixel(new int[tableauPortion[ind].largeur*tableauPortion[ind].hauteur]);
					}
					else {
						tableauPortion[ind].ordre = ind;
						tableauPortion[ind].debutX = tableauPortion[ind-1].debutX+tableauPortion[ind-1].largeur;
						tableauPortion[ind].debutY = tableauPortion[ind-1].debutY;
						tableauPortion[ind].largeur = width/divX;
						tableauPortion[ind].hauteur = height/divY;
						tableauPortion[ind].setPixel(new int[tableauPortion[ind].largeur*tableauPortion[ind].hauteur]);
					}

				}
				ind++;
			}
		}

		for (int v=0; v<Ihm.nbPortion; v++) 
			tableauPortion[v].setPixel(buf.getRGB(tableauPortion[v].debutX, tableauPortion[v].debutY, tableauPortion[v].largeur, 
					tableauPortion[v].hauteur, null, 0, tableauPortion[v].largeur));


		return tableauPortion;
	}

	public BufferedImage assemblage(Portion_Image[] tab){
		int width = 0;
		int height = 0;
		Portion_Image[] tabTrie = trier(tab);
		height = tabTrie[0].hauteur+tabTrie[tabTrie.length-1].hauteur;
		for(int i=0;i<(tabTrie.length/2); i++)			
			width+=tabTrie[i].largeur;

		BufferedImage resultBuf = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		for (int i=0;i<tabTrie.length;i++) 
			resultBuf.setRGB(tabTrie[i].debutX, tabTrie[i].debutY, tabTrie[i].largeur, 
					tabTrie[i].hauteur, tabTrie[i].getPixel(), 0, tabTrie[i].largeur);

		return resultBuf;
	}

	private Portion_Image[] trier(Portion_Image[] tab) {
		int j;
		for (int i=0; i<tab.length; i++){
			j = i;
			while (j < tab.length){
				if (tab[i].ordre > tab[j].ordre) {
					Portion_Image tmp = tab[i];
					tab[i] = tab[j];
					tab[j] = tmp;
				}
				j++;
			}
		}
		return tab;
	}


}
