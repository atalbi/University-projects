package pack;
import java.io.Serializable;

/**
 * Classe utilitaire permettant de définir les caractéristiques d'une machine (serveur ou client ou réseau)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Machine implements Serializable{

	private static final long serialVersionUID = 1L;
	public String nom;
	public String machine;
	public int port;

	public Machine(String nom,String machine,int port) {
		this.nom=nom;
		this.machine=machine;
		this.port=port;
	}

}
