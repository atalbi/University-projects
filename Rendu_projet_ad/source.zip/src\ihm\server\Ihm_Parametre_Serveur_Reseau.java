package ihm.server;


import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.rmi.RemoteException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import pack.Machine;
import serveur.Serveur;

/**
 * IHM appelé par l'IHM Serveu pour la configuration des paramètres réseaux de chaque de serveur
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Parametre_Serveur_Reseau extends JDialog{

	private static final long serialVersionUID = 1L;
	JPanel jp, jp1, jp2, jp3, jp4;
	JButton valider, cancel;
	Ihm_Serveur ihmServ;
	private JTextField nomServeur, adresseServeur, portServeur;
	private JLabel lab1, lab2, lab3, lab22, lab11, lab33;
	private JTextField nomReseau, adresseReseau, portReseau;


	public Ihm_Parametre_Serveur_Reseau(Ihm_Serveur ih) {
		this.ihmServ = ih;
		init();
	}


	private void init(){
		setTitle("Parametrage Serveur...");
		this.setSize(new Dimension(310,250));
		this.setLocationRelativeTo(ihmServ);
		this.setResizable(false);
		this.setModal(true);
		jp = new JPanel();
		GridLayout grid = new GridLayout(3,2);
		grid.setVgap(3);
		BoxLayout box = new BoxLayout(jp, BoxLayout.Y_AXIS);
		jp.setLayout(box);

		valider = new JButton("Valider");
		valider.setActionCommand("btnValider");
		valider.addActionListener(new Ecouteur());
		jp2 = new JPanel();
		cancel = new JButton("Annuler");
		cancel.setActionCommand("btnAnnuler");
		cancel.addActionListener(new Ecouteur());

		jp1 = new JPanel();
		jp1.setLayout(grid);
		jp3 = new JPanel();
		jp3.setLayout(grid);

		nomReseau = new JTextField();			
		lab1 = new JLabel("Nom machine Reseau ");
		adresseReseau = new JTextField();
		lab2 = new JLabel("Adresse machine Reseau ");
		portReseau = new JTextField();
		lab3 = new JLabel("Port machine Reseau ");
		if (ihmServ.machineReseau != null) {
			adresseReseau.setText(ihmServ.machineReseau.machine);
			nomReseau.setText(ihmServ.machineReseau.nom);
			portReseau.setText(""+ihmServ.machineReseau.port);
		}
		else {
			portReseau.setText("8000");
			nomReseau.setText("Machine_Reseau");
		}

		jp1.add(lab1);
		jp1.add(nomReseau);
		jp1.add(lab2);
		jp1.add(adresseReseau);
		jp1.add(lab3);
		jp1.add(portReseau);

		nomServeur = new JTextField();
		nomServeur.setText("Machine_Serveur_");
		lab11 = new JLabel("Nom serveur ");

		adresseServeur = new JTextField();
		lab22 = new JLabel("Adresse serveur ");

		portServeur = new JTextField();

		lab33 = new JLabel("Port serveur ");
		if (ihmServ.getServeur() != null ) {
			nomServeur.setText(ihmServ.getServeur().getMachineServeur().nom);
			adresseServeur.setText(ihmServ.getServeur().getMachineServeur().machine);
			portServeur.setText(""+ihmServ.getServeur().getMachineServeur().port);
		}
		else {
			nomServeur.setText("Machine_Serveur_");
			portServeur.setText("7000");
			try {
				adresseServeur.setText(Inet4Address.getLocalHost().getHostName());
			} catch (UnknownHostException e) {e.printStackTrace();}	
		}

		jp3.add(lab11);
		jp3.add(nomServeur);
		jp3.add(lab22);
		jp3.add(adresseServeur);
		jp3.add(lab33);
		jp3.add(portServeur);

		jp.add(new JLabel(" "));
		jp.add(jp3);
		jp.add(new JLabel(" "));

		jp.add(jp1);

		jp2.add(valider);
		jp2.add(cancel);
		jp.add(jp2);
		this.add(jp);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});
		setVisible(true);
	}

	class Ecouteur implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			if (arg0.getActionCommand().equals("btnValider")){
				if 		(!Ihm_Parametre_Serveur_Reseau.this.nomServeur.getText().equals("") && 
						!Ihm_Parametre_Serveur_Reseau.this.adresseServeur.getText().equals("") && 
						!Ihm_Parametre_Serveur_Reseau.this.portServeur.getText().equals("") &&
						!Ihm_Parametre_Serveur_Reseau.this.nomReseau.getText().equals("") && 
						!Ihm_Parametre_Serveur_Reseau.this.adresseReseau.getText().equals("") && 
						!Ihm_Parametre_Serveur_Reseau.this.portReseau.getText().equals("")){
					int port = 0;
					try {
						port = Integer.parseInt(Ihm_Parametre_Serveur_Reseau.this.portServeur.getText());
					} catch (NumberFormatException e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(Ihm_Parametre_Serveur_Reseau.this, "Erreur sur le format du numero de port saisi !", "Erreur", JOptionPane.ERROR_MESSAGE);
						Ihm_Parametre_Serveur_Reseau.this.ihmServ.getLog().append("\n> Erreur sur le format du numero de port saisi ");
					}
					try{
						Serveur serv = new Serveur(Ihm_Parametre_Serveur_Reseau.this.nomServeur.getText(),
								Ihm_Parametre_Serveur_Reseau.this.adresseServeur.getText(),
								port, Ihm_Parametre_Serveur_Reseau.this.ihmServ);
						Machine reseau = new Machine(Ihm_Parametre_Serveur_Reseau.this.nomReseau.getText(),
								Ihm_Parametre_Serveur_Reseau.this.adresseReseau.getText(), 
								Integer.parseInt(Ihm_Parametre_Serveur_Reseau.this.portReseau.getText()));

						Ihm_Parametre_Serveur_Reseau.this.ihmServ.setServeur(serv);
						Ihm_Parametre_Serveur_Reseau.this.ihmServ.machineReseau = reseau;

						if (Ihm_Parametre_Serveur_Reseau.this.ihmServ.getServeur() != null && Ihm_Parametre_Serveur_Reseau.this.ihmServ.machineReseau != null) {
							Ihm_Parametre_Serveur_Reseau.this.ihmServ.getLog().append("\n> Parametres réseaux(Nom: "+serv.getMachineServeur().nom+
									", adresse: "+serv.getMachineServeur().machine+", port:"+serv.getMachineServeur().port+") du serveur configurés avec succès");
							Ihm_Parametre_Serveur_Reseau.this.ihmServ.lancer.setEnabled(true);
							Ihm_Parametre_Serveur_Reseau.this.ihmServ.configServSuiv.setEnabled(true);
							Ihm_Parametre_Serveur_Reseau.this.dispose();
						}
					}
					catch (RemoteException e) {
						e.printStackTrace();
					}
				}
				else {
					JOptionPane.showMessageDialog(Ihm_Parametre_Serveur_Reseau.this, "Veuillez verifier que tous les champs obligatoires sont correctement remplis !", 
							"Erreur", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if (arg0.getActionCommand().equals("btnAnnuler")){
				if (!Ihm_Parametre_Serveur_Reseau.this.nomServeur.getText().equals("") || 
						!Ihm_Parametre_Serveur_Reseau.this.adresseServeur.getText().equals("") || 
						!Ihm_Parametre_Serveur_Reseau.this.portServeur.getText().equals("") ||
						!Ihm_Parametre_Serveur_Reseau.this.nomReseau.getText().equals("") || 
						!Ihm_Parametre_Serveur_Reseau.this.adresseReseau.getText().equals("") || 
						!Ihm_Parametre_Serveur_Reseau.this.portReseau.getText().equals("")){
					Ihm_Parametre_Serveur_Reseau.this.nomServeur.setText(""); 
					Ihm_Parametre_Serveur_Reseau.this.adresseServeur.setText(""); 
					Ihm_Parametre_Serveur_Reseau.this.portServeur.setText("");
					Ihm_Parametre_Serveur_Reseau.this.nomReseau.setText("");
					Ihm_Parametre_Serveur_Reseau.this.adresseReseau.setText(""); 
					Ihm_Parametre_Serveur_Reseau.this.portReseau.setText("");
				}
				else {
					Ihm_Parametre_Serveur_Reseau.this.dispose();
				}
			}

		}

	}
}
