package ihm.client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;

import pack.IObservable;
import pack.IObserver;
import traitement_image.Decoupage;
import client.Client;

/**
 * IHM principal client qui lui permet d'interagir avec le système(charger une image, 
 * lancer des traitements sur un serveur distant, récupérer et afficher le résultat, etc)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm extends JFrame implements IObserver{

	private static final long serialVersionUID = 1L;
	final static int nGris = 1;
	final static int Satur = 2;
	final static int Cont = 3;
	final static int rvb = 4;

	JMenuBar menuBar = new JMenuBar();
	boolean imageModified, loadOrNot, configReseauOrNot;
	JPanel pan, panG, panD;
	JScrollPane scroll;
	String sbuffer;
	JLabel picture;
	JToolBar tb;
	String imageLoadPath;
	String currentFolder;
	BufferedImage imageLoadBuff, imageLoadBuffInit;
	private BufferedImage imageLoadBuffSuiv;
	private BufferedImage imageLoadBuffPrec;
	JScrollPane scrollPaneG,scrollPaneD;
	Dimension defaultImageDim;
	Decoupage decoupe;
	JButton unDo, reDo, stop;
	JMenuItem sMenuFinish;
	JCheckBoxMenuItem jcMenuRouge, jcMenuBleu, jcMenuVert;
	JTextArea log;
	public static int nbPortion;
	Client client;
	public int[] pixelSuiv, pixelPrec;

	public Ihm(String titre) {
		client =null;
		setTitle(titre);
		setSize(new Dimension(800, 600));
		this.setLocation(200, 100);
		nbPortion = 6;
		JMenu mFichier = new JMenu("Fichier");
		currentFolder = "";
		JMenuItem sMenuLoad = new JMenuItem("Charger une image");
		sMenuLoad.addActionListener(new EcouteurMenu(this));
		sMenuLoad.setActionCommand("loadImage");
		mFichier.add(sMenuLoad);

		JMenuItem sMenuSave = new JMenuItem("Enregistrer");
		sMenuSave.addActionListener(new EcouteurMenu(this));
		sMenuSave.setActionCommand("saveImage");
		mFichier.add(sMenuSave);

		JMenuItem sMenuExit = new JMenuItem("Quitter");
		sMenuExit.addActionListener(new EcouteurMenu(this));
		sMenuExit.setActionCommand("quitter");
		mFichier.add(sMenuExit);

		menuBar.add(mFichier);

		JMenu mImage = new JMenu("Image");

		JMenuItem sMenuGris = new JMenuItem("Filtre Niveau de gris");
		sMenuGris.addActionListener(new EcouteurMenu(this));
		sMenuGris.setActionCommand("niveauGris");
		mImage.add(sMenuGris);

		JMenuItem sMenuContour = new JMenuItem("Filtre Detection de contour");
		sMenuContour.addActionListener(new EcouteurMenu(this));
		sMenuContour.setActionCommand("contour");
		mImage.add(sMenuContour);


		JMenu sMenuRvb = new JMenu("Filtre RVB");
		jcMenuRouge = new JCheckBoxMenuItem("Rouge");
		jcMenuRouge.setEnabled(false);jcMenuRouge.setSelected(true);
		jcMenuRouge.addItemListener(new EcouteurMenu(this));

		jcMenuVert = new JCheckBoxMenuItem("Vert");
		jcMenuVert.addItemListener(new EcouteurMenu(this));
		jcMenuVert.setEnabled(false);jcMenuVert.setSelected(true);

		jcMenuBleu = new JCheckBoxMenuItem("Bleu");
		jcMenuBleu.addItemListener(new EcouteurMenu(this));
		jcMenuBleu.setEnabled(false);
		jcMenuBleu.setSelected(true);



		sMenuRvb.add(jcMenuBleu);
		sMenuRvb.add(jcMenuRouge);
		sMenuRvb.add(jcMenuVert);
		mImage.add(sMenuRvb);

		JMenuItem sMenuSaturation = new JMenuItem("Filtre Saturation(-200)");
		sMenuSaturation.addActionListener(new EcouteurMenu(this));
		sMenuSaturation.setActionCommand("saturation");
		mImage.add(sMenuSaturation);
		menuBar.add(mImage);

		JMenu mAdmin;
		mAdmin = new JMenu("Administration");
		JMenuItem sMenuConnexionClient = new JMenuItem("Parametres de connexion Client");
		sMenuConnexionClient.addActionListener(new EcouteurMenu(this));
		sMenuConnexionClient.setActionCommand("config_connexion_client");
		mAdmin.add(sMenuConnexionClient);
		JMenuItem sMenuConnexionServeur = new JMenuItem("Parametres de connexion Serveur");
		sMenuConnexionServeur.addActionListener(new EcouteurMenu(this));
		sMenuConnexionServeur.setActionCommand("config_connexion_serveur");
		mAdmin.add(sMenuConnexionServeur);
		JMenuItem sMenuDecoupe = new JMenuItem("Parametrer le decoupage");
		sMenuDecoupe.addActionListener(new EcouteurMenu(this));
		sMenuDecoupe.setActionCommand("decoupe");
		mAdmin.add(sMenuDecoupe);
		sMenuFinish = new JMenuItem("Terminer l'execution");
		sMenuFinish.addActionListener(new EcouteurMenu(this));
		sMenuFinish.setActionCommand("terminer");
		mAdmin.add(sMenuFinish);
		menuBar.add(mAdmin);

		picture = new JLabel();
		picture.setFont(picture.getFont().deriveFont(Font.ITALIC));
		picture.setHorizontalAlignment(JLabel.CENTER);
		log = new JTextArea();
		log.setAutoscrolls(true);
		log.setEditable(false);
		pan = new JPanel();
		panG = new JPanel();
		panD = new JPanel();
		panD.add(picture, BorderLayout.CENTER);
		scrollPaneG = new JScrollPane(log);
		scrollPaneD = new JScrollPane(panD);
		JSplitPane splitPan = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollPaneD, scrollPaneG );
		splitPan.setOneTouchExpandable(true);
		splitPan.setDividerLocation(450);
		defaultImageDim = new Dimension(800, 450);
		splitPan.setPreferredSize(new Dimension(800, 600));
		scrollPaneG.setMinimumSize(new Dimension(800, 150));

		tb = new JToolBar();
		unDo = new JButton(new ImageIcon(getClass().getResource("/previous.gif")));
		unDo.setActionCommand("unDo");
		unDo.addActionListener(new EcouteurMenu(this));
		unDo.setEnabled(false);
		unDo.setToolTipText("Annuler le dernier filtre appliqué");
		reDo = new JButton(new ImageIcon(getClass().getResource("/next.gif")));
		reDo.setActionCommand("reDo");
		reDo.addActionListener(new EcouteurMenu(this));
		reDo.setEnabled(false);
		reDo.setToolTipText("Rétablir le dernier filtre appliqué");
		stop = new JButton(new ImageIcon(getClass().getResource("/stop.gif")));
		stop.setActionCommand("terminer");
		stop.addActionListener(new EcouteurMenu(this));
		stop.setEnabled(false);
		stop.setToolTipText("Lancer la terminaison des serveurs");
		tb.add(unDo);
		tb.add(reDo);
		tb.add(stop);
		this.add(tb, BorderLayout.NORTH);

		getContentPane().add(splitPan);
		this.setJMenuBar(menuBar);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		setVisible(true);

		this.addWindowListener(new WindowAdapter() {
			@SuppressWarnings("static-access")
			public void windowClosing(WindowEvent we) {
				if (Ihm.this.imageModified) {
					JOptionPane jOpt = new JOptionPane();
					int ok = jOpt.showConfirmDialog(Ihm.this, "Voulez-vous sauvegarder l'image", "PROJET AD", JOptionPane.YES_NO_OPTION);
					if (ok == JOptionPane.OK_OPTION) {
						String approve = new String("Enregistrer");
						JFileChooser fc = new JFileChooser();
						int resultatEnregistrer = fc.showDialog(fc, approve);

						if (resultatEnregistrer == fc.APPROVE_OPTION) {
							JFileChooser chooser = new JFileChooser();
							chooser.setCurrentDirectory(new File(Ihm.this.currentFolder));
							chooser.setDialogTitle("Enregistrement");
							if (chooser.showSaveDialog(Ihm.this) == JFileChooser.APPROVE_OPTION) {
								try {
									ImageIO.write(Ihm.this.getImageLoadBuff(), "png", new java.io.File(chooser.getSelectedFile().getAbsolutePath()));
								} catch (Exception e1) {
									JOptionPane.showMessageDialog(Ihm.this, e1.getMessage(),"Erreur",JOptionPane.ERROR_MESSAGE);
								}
							}
							
						}
						
					}	
					Ihm.this.dispose();
				}
			}
		});
	}

	public void setImageLoadPath(String imageLoadPath) {
		this.imageLoadPath = imageLoadPath;
	}

	public String getImageLoadPath() {
		return imageLoadPath;
	}

	public void setCurrentFolder(String currentF) {
		this.currentFolder = currentF;
	}
	public String getCurrentFolder() {
		return currentFolder;
	}

	public void setImageLoadBuff(BufferedImage imageLoad) {
		this.imageLoadBuff = imageLoad;
	}

	public BufferedImage getImageLoadBuff() {
		return imageLoadBuff;
	}

	public void setDecoupe(Decoupage decoup) {
		this.decoupe = decoup;
	}

	public Decoupage getDecoupe() {
		return decoupe;
	}

	public void displayImage(String path) {

		try {
			client.setImage(path);
			client.pi = new Decoupage().decoupe(client.getImage());
			imageLoadBuff = client.getImage().getImageBuffered();
		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Erreur chargement image !","Erreur",JOptionPane.ERROR_MESSAGE);
			this.log.append("\n> Erreur lors du chargement l'image");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		Image newIcon = imageLoadBuff.getScaledInstance(imageLoadBuff.getWidth(), imageLoadBuff.getHeight(), Image.SCALE_DEFAULT);
		picture.setIcon(new ImageIcon(newIcon));
		picture.setText("");
		pixelPrec = null;
		pixelSuiv = null;
		unDo.setEnabled(false);
		reDo.setEnabled(false);
		//on rend inactives les 3 options puis on les selectionne toutes avant de les reactiver afin d'eviter que les 
		// listeners ne fonctionnent entre temps
		jcMenuBleu.setEnabled(false);
		jcMenuRouge.setEnabled(false);
		jcMenuVert.setEnabled(false);
		jcMenuBleu.setSelected(true);
		jcMenuRouge.setSelected(true);
		jcMenuVert.setSelected(true);
		jcMenuBleu.setEnabled(true);
		jcMenuRouge.setEnabled(true);
		jcMenuVert.setEnabled(true);
	}

	public void refreshImage(){
		Image newIcon = imageLoadBuff.getScaledInstance(imageLoadBuff.getWidth(), imageLoadBuff.getHeight(), Image.SCALE_DEFAULT);
		picture.setIcon(new ImageIcon(newIcon));
		picture.setText("");
	}

	public void init(BufferedImage buf){
		setImageLoadBuff(buf);
	}

	public void activePrecedent(){
		if (unDo.isEnabled()==false)
			unDo.setEnabled(true);

	}

	public void activeSuivant(){
		if (reDo.isEnabled()==false)
			reDo.setEnabled(true);

	}

	public void desactiveSuivant(){
		if (reDo.isEnabled()== true)
			reDo.setEnabled(false);
	}

	public void activeStop(){
		if (stop.isEnabled()==false) {
			stop.setEnabled(true);
			sMenuFinish.setEnabled(true);
		}
		else {
			stop.setEnabled(false);
			sMenuFinish.setEnabled(false);
		}

	}
	
	public void setLog(JTextArea log) {
		this.log = log;
	}

	public JTextArea getLog() {
		return log;
	}

	public static void log(String msg) {
		System.out.println(msg); System.out.flush();
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Client getClient() {
		return client;
	}

	@Override
	public void updateLog(IObservable o, String info) {
		if (o instanceof Client) {
			if (info.startsWith("1")) {//cas de reception de resultat de traitement
				refreshImage();
				log.append("\n> "+info.substring(1, info.length()));
			}
			else //cas de log simple
				log.append("\n> "+info);
		}
	}

	public void setImageLoadBuffPrec(BufferedImage imageLoadBuffPrec) {
		this.imageLoadBuffPrec = imageLoadBuffPrec;
	}

	public BufferedImage getImageLoadBuffPrec() {
		return imageLoadBuffPrec;
	}

	public void setImageLoadBuffSuiv(BufferedImage imageLoadBuffSuiv) {
		this.imageLoadBuffSuiv = imageLoadBuffSuiv;
	}

	public BufferedImage getImageLoadBuffSuiv() {
		return imageLoadBuffSuiv;
	}

}
