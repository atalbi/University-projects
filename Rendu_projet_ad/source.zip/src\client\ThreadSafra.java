package client;

import java.awt.Cursor;
import java.rmi.RemoteException;

import jeton.Jeton;
import jeton.JetonSafra;
import serveur.IServeur;

/**
 * Thread permettant de lancer le processus de terminaison des serveurs
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class ThreadSafra extends Thread {
	IServeur serveur;
	Client client;
	
	public ThreadSafra(Client clt, IServeur serveur) {
		this.serveur = serveur;
		this.client = clt;

	}
	
	
	public void run(){
		client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		
		//creation du jeton de safra pour le processus de terminaison
		JetonSafra jt = new JetonSafra(Jeton.BLANC, 0);
		try {
			serveur.recevoirJeton(jt); //envoi du jeton au serveur 
			client.state = new String("Processus de detection de terminaison et d'arret des serveurs, lancé...");
			client.notifyObservers();
		} catch (RemoteException e) {
			client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			e.printStackTrace();
		}
		client.ih.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

}
