package reseau;

import ihm.reseau.Ihm_Reseau;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;

import jeton.Jeton;
import jeton.JetonSafra;
import jeton.JetonStop;
import jeton.JetonTraitement;
import pack.IObservable;
import pack.IObserver;
import pack.Machine;
import serveur.IServeur;

/**
 * Classe definissant les informations relatives à la machine réseau qui joue le rôle de hub dans
 * cette topologie en étoile. 
 * @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Reseau extends UnicastRemoteObject implements IReseau, IObservable {

	private static final long serialVersionUID = 1L;
	Machine machineReseau;
	Registry registryReseau;
	ArrayList<IObserver> listOfObservers;
	String state; 
	HashMap<String, Jeton> listeJetons;

	
	/**
	 * Constructeur permettant de définir une machine réseau avec ses caractéristiques
	 * @param nomReseau
	 * @param machineReseau
	 * @param port
	 * @throws RemoteException
	 */
	public Reseau(String nomReseau, String machineReseau, int port)
			throws RemoteException {
		super();
		listeJetons = new HashMap<String, Jeton>();
		listOfObservers = new ArrayList<IObserver>();
		this.machineReseau = new Machine(nomReseau, machineReseau, port);

		registryReseau = LocateRegistry.createRegistry(port);
		registryReseau.rebind(nomReseau, this);

		System.out.println("Reseau ready!!!!");

	}

	
	/**
	 * Constructeur permettant de définir une machine réseau avec ses caractéristiques (instance de l'Ihm Réseau inclue)
	 * @param nomReseau
	 * @param machineReseau
	 * @param port
	 * @param ih
	 * @throws RemoteException
	 */
	public Reseau(String nomReseau, String machineReseau, int port, Ihm_Reseau ih) throws RemoteException {
		this(nomReseau, machineReseau, port);
		addObserver(ih);//A un Reseau correspond une seule ihm d'administration, ce qui permet de gerer ses log
	}
	
	
	/** 
	 * Fonction invoquée à distance par les serveurs pour le transfert de jeton 
	 * à leurs successeurs dans la topologie.
	 * @param jeton (de type traitement ou Safra ou Stop)
	 * @param servSuiv
	 */
	@SuppressWarnings("static-access")
	public void envoiJetonSuiv(Jeton jeton, Machine servSuiv) throws RemoteException {
		if (jeton instanceof JetonTraitement) {
			state = new String("Envoi jeton numero "+((JetonTraitement)jeton).pi+" (relatif au client "+((JetonTraitement)jeton).machineClient.nom+") au serveur("+servSuiv.nom+")");
			notifyObservers();
		}
		else if (jeton instanceof JetonSafra) {
			state = new String("Envoi jeton Detection terminaison au serveur("+servSuiv.nom+")");
			notifyObservers();
		}
		else if (jeton instanceof JetonStop) {
			state = new String("Envoi jeton Stop au serveur("+servSuiv.nom+")");
			notifyObservers();
		}
		IServeur serveur;
		try {

			//transfert du jeton au serveur suivant après un sleep d'une dirée aléatoire proportionnelle au délai délai par l'administrateur
			Registry regTmp = LocateRegistry.getRegistry(servSuiv.machine,servSuiv.port);
			serveur = (IServeur) regTmp.lookup(servSuiv.nom);
			Thread.currentThread().sleep((long) (Ihm_Reseau.delai * Math.random()));// .sleep((long)
			serveur.recevoirJeton(jeton);
		} catch (NotBoundException e) {
			state = new String("Erreur(type NotBoundException) lors de la tentative d'envoi du jeton au serveur "+servSuiv.nom);
			notifyObservers();
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Getter de la machine réseau
	 * @return machineReseau
	 */
	public Machine getMachineReseau() {
		return machineReseau;
	}
	
	/* (non-Javadoc)
	 * @see pack.IObservable#addObserver(pack.IObserver)
	 */
	@Override
	public void addObserver(IObserver o) {
		listOfObservers.add(o);		
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#notifyObservers()
	 */
	@Override
	public void notifyObservers() {
		if (!state.equals(new String("")))
			for (IObserver o: listOfObservers){
				o.updateLog(this, state);
			}
		state = new String("");
	}


	/* (non-Javadoc)
	 * @see pack.IObservable#removeObserver(pack.IObserver)
	 */
	@Override
	public void removeObserver(IObserver o) {
		listOfObservers.remove(o);		
	}
	
	/**
	 * Fonction permettant de référencer un jeton. Ce qui permet de traiter les jetons de plusieurs clients en 
	 * conservant chaque fois un lien unique entre chaque jeton et le client associé
	 * @param jeton : de type traitement
	 */
	public void setJeton(Jeton jeton) throws RemoteException{
		if (jeton instanceof JetonTraitement)
			this.listeJetons.put(((JetonTraitement)jeton).machineClient.nom, jeton);
	}
	
	/**
	 * Getter de jeton. retourne le jeton correspondant à un client donné
	 * @param idClient : reference client
	 * @return jeton
	 */
	public Jeton getJeton(String idClient) throws RemoteException{
		return listeJetons.get(idClient);
	}

	/**
	 * Fonction permettant de redéfinir le numero de portion d'images disponible pour traitement
	 */
	@Override
	public void setJetonPi(String idClient, int pi) throws RemoteException {
		((JetonTraitement)listeJetons.get(idClient)).pi = pi;
		
	}
	
	/**
	 * Fonction permettant de supprimer de la liste des jetons, un jeton lié à un client dont le traitement est terminé 
	 */
	@Override
	public void deleteJeton (String idClient) throws RemoteException{
		this.listeJetons.remove(idClient);
	}

	/**
	 * Fonction permettant à un serveur de tester sa connexion avec le réseau
	 */
	@Override
	public void ping(String nomServ) throws RemoteException {
		state = new String("Connexion du serveur "+nomServ);
		notifyObservers();
		
	}
}
