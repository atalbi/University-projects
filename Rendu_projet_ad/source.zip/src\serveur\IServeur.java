package serveur;

import java.rmi.Remote;
import java.rmi.RemoteException;

import jeton.Jeton;
import pack.Machine;

/**
 * Interface Remote definissant les méthodes du serveur, accessibles à distance
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public interface IServeur extends Remote {
	public Machine getMachineServeur()throws RemoteException;
	public void recevoirJeton(Jeton jt) throws RemoteException;
	public Machine getServeurSuiv() throws RemoteException;
	void ping(String nomClient) throws RemoteException;
	public boolean isLaunchTerm() throws RemoteException;
	
}
