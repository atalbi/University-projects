package ihm.client;


import ihm.server.Ihm_Serveur;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import pack.Machine;
import serveur.IServeur;

/**
 * IHM permettant de configurer les paramètres réseaux  du serveur suivant et du serveur auquel est connecté le client
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Parametre_Serveur extends JDialog{

	private static final long serialVersionUID = 1L;
	JPanel jp, jp2, jp3;
	JButton add, cancel;
	Ihm ih;
	Ihm_Serveur ihmServ;
	private JTextField nomServeur, adresseServeur, portServeur;
	private JLabel lab22, lab11, lab33;



	public Ihm_Parametre_Serveur(Ihm ih) {
		this.ih = ih;
		ihmServ =null;
		init();

	}

	public Ihm_Parametre_Serveur(Ihm_Serveur ihServ) {
		this.ih = null;
		this.ihmServ = ihServ;
		init();

	}

	private void init(){

		this.setSize(new Dimension(320,170));
		this.setModal(true);
		this.setResizable(false);

		jp = new JPanel();
		GridLayout grid = new GridLayout(3,2);
		grid.setVgap(3);
		BoxLayout box = new BoxLayout(jp, BoxLayout.Y_AXIS);
		jp.setLayout(box);

		add = new JButton("Valider");
		add.addActionListener(new Ecouteur());
		jp2 = new JPanel();
		cancel = new JButton("Annuler");
		cancel.setActionCommand("btnAnnuler");
		cancel.addActionListener(new Ecouteur());

		jp3 = new JPanel();
		jp3.setLayout(grid);
		nomServeur = new JTextField();
		adresseServeur = new JTextField();
		portServeur = new JTextField();

		if (ih == null && ihmServ != null){
			setTitle("Parametrage Serveur suivant...");
			this.setLocationRelativeTo(ihmServ);
			add.setActionCommand("btnValiderServSuiv");
			lab11 = new JLabel("Nom serveur suivant");
			lab22 = new JLabel("Adresse serveur suivant");
			lab33 = new JLabel("Port serveur suivant");
			if (ihmServ.getServeur() != null && ihmServ.getServeur().getServeurSuiv()!=null) {
				nomServeur.setText(ihmServ.getServeur().getServeurSuiv().nom);
				adresseServeur.setText(ihmServ.getServeur().getServeurSuiv().machine);
				portServeur.setText(""+ihmServ.getServeur().getServeurSuiv().port);
			}

		}
		else if (ihmServ == null && ih != null){
			setTitle("Parametrage Serveur...");
			this.setLocationRelativeTo(ih);
			add.setActionCommand("btnValiderServ");
			lab11 = new JLabel("Nom machine serveur ");
			lab22 = new JLabel("Adresse machine serveur");
			lab33 = new JLabel("Port machine serveur");
			try {
				if (ih.getClient() != null && ih.getClient().getServeur() != null){
					nomServeur.setText(ih.getClient().getServeur().getMachineServeur().nom);
					adresseServeur.setText(ih.getClient().getServeur().getMachineServeur().machine);
					portServeur.setText(""+ih.getClient().getServeur().getMachineServeur().port);
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}



		jp3.add(lab11);
		jp3.add(nomServeur);
		jp3.add(lab22);
		jp3.add(adresseServeur);
		jp3.add(lab33);
		jp3.add(portServeur);

		jp.add(new JLabel(" "));
		jp.add(jp3);
		jp2.add(add);
		jp2.add(cancel);
		jp.add(jp2);
		this.add(jp);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});
		setVisible(true);
	}

	class Ecouteur implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (arg0.getActionCommand().equals("btnValiderServ") || arg0.getActionCommand().equals("btnValiderServSuiv")){
				int port = 0;
				try {
					port = Integer.parseInt(Ihm_Parametre_Serveur.this.portServeur.getText());
				}
				catch (NumberFormatException e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(Ihm_Parametre_Serveur.this, "Erreur sur le format du numero de port saisi !", "Erreur", JOptionPane.ERROR_MESSAGE);
					Ihm_Parametre_Serveur.this.ih.log.append("\n> Erreur sur le format du numero de port saisi pour le serveur");
				}

				if (	!Ihm_Parametre_Serveur.this.nomServeur.getText().equals("") && 
						!Ihm_Parametre_Serveur.this.adresseServeur.getText().equals("") && 
						!Ihm_Parametre_Serveur.this.portServeur.getText().equals("")){


					if (arg0.getActionCommand().equals("btnValiderServ")){
						if (Ihm_Parametre_Serveur.this.ih.client == null) {
							JOptionPane.showMessageDialog(Ihm_Parametre_Serveur.this, "Veillez configurer les parametres réseau du client d'abord !",
									"Erreur", JOptionPane.ERROR_MESSAGE);
						}
						else if (Ihm_Parametre_Serveur.this.ih.client.connectServeur(Ihm_Parametre_Serveur.this.nomServeur.getText(),
								Ihm_Parametre_Serveur.this.adresseServeur.getText(),port) == false) {

							JOptionPane.showMessageDialog(Ihm_Parametre_Serveur.this, "Erreur lors de la connexion à la machine Serveur !",
									"Erreur", JOptionPane.ERROR_MESSAGE);
						}
						else {

							Ihm_Parametre_Serveur.this.ih.configReseauOrNot = true;
							Ihm_Parametre_Serveur.this.dispose();

						}
					}

					else {
						Machine serveurSuiv = new Machine(Ihm_Parametre_Serveur.this.nomServeur.getText(), 
								Ihm_Parametre_Serveur.this.adresseServeur.getText(),port );

						if (Ihm_Parametre_Serveur.this.ihmServ.getServeur() != null) {
							Ihm_Parametre_Serveur.this.ihmServ.getServeur().setServeurSuiv(serveurSuiv);

							Registry regTmp = null;
							IServeur sS = null;
							try {
								regTmp = LocateRegistry.getRegistry(Ihm_Parametre_Serveur.this.adresseServeur.getText(), port);

								sS = (IServeur) regTmp.lookup(Ihm_Parametre_Serveur.this.nomServeur.getText());
								Ihm_Parametre_Serveur.this.ihmServ.getLog().append("\n> Ajout de la machine "+Ihm_Parametre_Serveur.this.nomServeur.getText()+
										"(Adresse: "+Ihm_Parametre_Serveur.this.adresseServeur.getText()+"/ port: "+Ihm_Parametre_Serveur.this.portServeur.getText()+") comme serveur suivant...");
								Ihm_Parametre_Serveur.this.dispose();

							} catch (RemoteException e) {
								e.printStackTrace();
								Ihm_Parametre_Serveur.this.ihmServ.getLog().append("\n> Erreur(type RemoteException) lors de la verification de l'existence du serveur suivant "
										+Ihm_Parametre_Serveur.this.adresseServeur.getText()+" dans le registry");
								String msg = "Le serveur suivant indiqué semble ne pas avoir été lancé, Cliquez sur Oui pour continuer ou Non s'il s'agit d'une erreur de saisie !";
								if (sS == null) {
									if (JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(Ihm_Parametre_Serveur.this,msg, "Confirmation saisie", JOptionPane.YES_NO_OPTION)){

										Ihm_Parametre_Serveur.this.ihmServ.getLog().append("\n> Ajout de la machine "+Ihm_Parametre_Serveur.this.nomServeur.getText()+
												"(Adresse: "+Ihm_Parametre_Serveur.this.adresseServeur.getText()+"/ port: "+Ihm_Parametre_Serveur.this.portServeur.getText()+") comme serveur suivant...");
										Ihm_Parametre_Serveur.this.dispose();
									}

								}
							} catch (NotBoundException e) {
								e.printStackTrace();
								Ihm_Parametre_Serveur.this.ihmServ.getLog().append("\n> Erreur(type NotBoundException) lors de la verification de l'existence du serveur suivant "
										+Ihm_Parametre_Serveur.this.adresseServeur.getText()+" dans le registry");
								String msg = "Le serveur suivant indiqué semble ne pas avoir été lancé, Cliquez sur Oui pour continuer ou Non s'il s'agit d'une erreur de saisie !";
								if (sS == null) {
									if (JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(Ihm_Parametre_Serveur.this,msg, "Confirmation saisie", JOptionPane.YES_NO_OPTION)){

										Ihm_Parametre_Serveur.this.ihmServ.getLog().append("\n> Ajout de la machine "+Ihm_Parametre_Serveur.this.nomServeur.getText()+
												"(Adresse: "+Ihm_Parametre_Serveur.this.adresseServeur.getText()+"/ port: "+Ihm_Parametre_Serveur.this.portServeur.getText()+") comme serveur suivant...");
										Ihm_Parametre_Serveur.this.dispose();
									}

								}
							}

						}

					}

				}

				else {
					JOptionPane.showMessageDialog(Ihm_Parametre_Serveur.this, "Veuillez verifier que tous les champs sont correctement remplis !", 
							"Erreur", JOptionPane.ERROR_MESSAGE);
				}
			}

			else if (arg0.getActionCommand().equals("btnAnnuler")){
				if (!Ihm_Parametre_Serveur.this.nomServeur.getText().equals("") || 
						!Ihm_Parametre_Serveur.this.adresseServeur.getText().equals("") || 
						!Ihm_Parametre_Serveur.this.portServeur.getText().equals("")){
					Ihm_Parametre_Serveur.this.nomServeur.setText(""); 
					Ihm_Parametre_Serveur.this.adresseServeur.setText(""); 
					Ihm_Parametre_Serveur.this.portServeur.setText("");
				}
				else {
					Ihm_Parametre_Serveur.this.dispose();
				}
			}

		}


	}
}
