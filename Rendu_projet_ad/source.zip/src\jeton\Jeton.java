package jeton;

import java.io.Serializable;

/**
 * Classe définissant les principales caractéristiques communes à tous les types de jetons implémentés(jetonSafra, jetonStop, etc)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Jeton implements Serializable{

	private static final long serialVersionUID = 1L;
	public final static int BLANC = 1;
	public final static int NOIR = 0;
	public String ServeurP0;

	public Jeton(String ServeurP0) {
		this.ServeurP0 = ServeurP0;
	}

}
