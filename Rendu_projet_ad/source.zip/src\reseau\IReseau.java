package reseau;

import java.rmi.Remote;
import java.rmi.RemoteException;

import jeton.Jeton;
import pack.Machine;

/**
 * Interface Remote definissant les méthodes de la machine réseau, accessibles à distance
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public interface IReseau extends Remote {
	public void envoiJetonSuiv(Jeton jeton, Machine servSuiv) throws RemoteException;
	public void setJeton(Jeton jeton) throws RemoteException;
	public void setJetonPi(String idClient, int pi) throws RemoteException;
	public Jeton getJeton(String idClient) throws RemoteException;
	public void deleteJeton(String idClient) throws RemoteException;
	public void ping(String nomServ) throws RemoteException;
}
