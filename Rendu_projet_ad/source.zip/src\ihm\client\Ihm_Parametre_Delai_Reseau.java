package ihm.client;


import ihm.reseau.Ihm_Reseau;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * IHM permettant à l'administrateur de configurer le paramètre délai de communication réseau
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Parametre_Delai_Reseau extends JDialog {

	private static final long serialVersionUID = 1L;
	JTextField delai;
	JLabel libelle;
	JPanel pan, pan1, pan2;
	JButton valider;
	Ihm_Reseau ih;
	@SuppressWarnings("static-access")
	public Ihm_Parametre_Delai_Reseau(Ihm_Reseau ih) {
		this.ih = ih;
		this.setModal(true);
		setLocationRelativeTo(ih);
		setTitle("Parametrage...");
		setResizable(false);
		GridLayout grid = new GridLayout(1,2);

		libelle = new JLabel("Delai transmission réseau: ");
		delai = new JTextField();
		delai.setText(""+ih.delai);
		delai.setColumns(4);
		valider = new JButton("Valider");
		valider.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				try {
					int nb = Integer.parseInt(Ihm_Parametre_Delai_Reseau.this.delai.getText());

					Ihm_Parametre_Delai_Reseau.this.ih.delai = nb;
					Ihm_Parametre_Delai_Reseau.this.ih.getLog().append("\n> Parametrage du délai de transmission réseau à "+Ihm_Parametre_Delai_Reseau.this.delai.getText());
					Ihm_Parametre_Delai_Reseau.this.setVisible(false);
				}
				catch (NumberFormatException e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(Ihm_Parametre_Delai_Reseau.this, "Format invalide pour le délai !", "Erreur", JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		pan = new JPanel();
		pan1 = new JPanel();
		pan2 = new JPanel();
		pan1.setLayout(grid);
		pan1.add(libelle);
		pan1.add(delai);
		pan.add(pan1);
		pan2.add(valider);
		pan.add(pan2);
		setContentPane(pan);
		setSize(new Dimension(350, 100));

		setVisible(true);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});


	}

}
