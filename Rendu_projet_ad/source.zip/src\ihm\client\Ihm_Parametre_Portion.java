package ihm.client;


import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * IHM permettant au client de configurer le nombre de portions d'images souhaité pour le découpage
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Parametre_Portion extends JDialog {

	private static final long serialVersionUID = 1L;
	JTextField nbPort;
	JLabel libelle;
	JPanel pan, pan1, pan2;
	JButton valider;
	Ihm ih;
	@SuppressWarnings("static-access")
	public Ihm_Parametre_Portion(Ihm ih) {
		this.ih = ih;
		this.setModal(true);
		setLocationRelativeTo(ih);
		setTitle("Parametrage...");
		setResizable(false);
		GridLayout grid = new GridLayout(1,2);

		libelle = new JLabel("Nb portions d'images: ");
		nbPort = new JTextField();
		nbPort.setText(""+ih.nbPortion);
		nbPort.setColumns(4);
		valider = new JButton("Valider");
		valider.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				try {
					int nb = Integer.parseInt(Ihm_Parametre_Portion.this.nbPort.getText());
					if (nb > 0 && nb < 100) {
						Ihm_Parametre_Portion.this.ih.nbPortion = nb;
						JOptionPane.showMessageDialog(Ihm_Parametre_Portion.this, "Veillez recharger une nouvelle image pour appliquer cette modification !", "Info", JOptionPane.INFORMATION_MESSAGE);
						Ihm_Parametre_Portion.this.ih.log.append("\n> Parametrage du nombre de portion d'images à "+Ihm_Parametre_Portion.this.nbPort.getText());
						Ihm_Parametre_Portion.this.setVisible(false);
					}
					else
						JOptionPane.showMessageDialog(Ihm_Parametre_Portion.this, "Le nombre de portions doit etre compris entre 1 et 100 ", "Erreur", JOptionPane.ERROR_MESSAGE);
				}
				catch (NumberFormatException e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(Ihm_Parametre_Portion.this, "Format invalide pour le nombre saisi !", "Erreur", JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		pan = new JPanel();
		pan1 = new JPanel();
		pan2 = new JPanel();
		pan1.setLayout(grid);
		pan1.add(libelle);
		pan1.add(nbPort);
		pan.add(pan1);
		pan2.add(valider);
		pan.add(pan2);
		setContentPane(pan);
		setSize(new Dimension(300, 100));

		setVisible(true);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});


	}

}
