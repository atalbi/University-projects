package ihm.client;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.rmi.RemoteException;

import javax.imageio.ImageIO;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * classe permettant de gerer tous les évenements relatifs aux boutons et menus divers de l'Ihm client 
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class EcouteurMenu implements ActionListener, ItemListener {
	Ihm myIhm;

	public EcouteurMenu(Ihm ih) {
		myIhm = ih;
	}

	@SuppressWarnings("static-access")
	@Override
	public void actionPerformed(ActionEvent e) {

		//cas du chargement du fichier
		if (e.getActionCommand().equals("loadImage")) {
			if (myIhm.client != null) {
				JFileChooser chooser = new JFileChooser();
				MyFileFilter filtre = new MyFileFilter( 
						new String[]{"bmp", "gif", "jpeg", "jpg", "png"},
				"les fichiers image (*.bmp, *.gif, *.jpeg, *.png)");				
				chooser.addChoosableFileFilter(filtre);			

				if(myIhm.currentFolder == "") chooser.setCurrentDirectory(new File("."));
				else chooser.setCurrentDirectory(new File(myIhm.currentFolder));

				if (chooser.showOpenDialog(myIhm) == JFileChooser.APPROVE_OPTION) {
					myIhm.setImageLoadPath(chooser.getSelectedFile().getAbsolutePath());
					myIhm.currentFolder = chooser.getSelectedFile().getParent();
					myIhm.log.append("\n---------------------");


					try {
						myIhm.loadOrNot = true;
						myIhm.displayImage(myIhm.getImageLoadPath());
						myIhm.log.append("\n> Chargement de l'image \""+chooser.getSelectedFile().getName()+"\"");
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(myIhm, "Erreur chargement image !","Erreur",JOptionPane.ERROR_MESSAGE);
						myIhm.log.append("\n> Erreur chargement image");
					}
				} 

			}
			else {
				JOptionPane.showMessageDialog(myIhm, "Veuillez d'abord indiquer les paramètres réseau du client !","Erreur",JOptionPane.ERROR_MESSAGE);
				myIhm.log.append("\n> Chargement image annulé car parametres réseau du client non configurés");
			}
		}

		// cas de l'enregistrement de l'image
		else if (e.getActionCommand().equals("saveImage")){
			if (myIhm.loadOrNot)
				save();
			else{
				JOptionPane jOpt = new JOptionPane();
				jOpt.showMessageDialog(myIhm, "Aucune image n'est chargée !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}


		// menu Quitter
		else if (e.getActionCommand().equals("quitter")){
			if (myIhm.imageModified) {
				JOptionPane jOpt = new JOptionPane();
				int ok = jOpt.showConfirmDialog(myIhm, "Voulez-vous sauvegarder l'image", "PROJET AD", JOptionPane.YES_NO_OPTION);
				if (ok == JOptionPane.OK_OPTION) 
					save();
					
				myIhm.dispose();
			}
			else 
				myIhm.dispose();
		}


		// application du filtre Niveau de Gris
		else if (e.getActionCommand().equals("niveauGris")) {
			if (myIhm.loadOrNot && myIhm.configReseauOrNot){

				Ihm.log("Niveaux de Gris");
				myIhm.log.append("\n> Filtre Niveuax de Gris");
				myIhm.client.demandeTraitement(Ihm.nGris, false, false, false);
				myIhm.imageModified = true;

			}
			else{
				JOptionPane jOpt = new JOptionPane();
				jOpt.showMessageDialog(myIhm, "Veuillez configurer tous les paramètres réseau et charger une image d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}

		// application du filtre Détection de contour
		else if (e.getActionCommand().equals("contour")){
			if (myIhm.loadOrNot && myIhm.configReseauOrNot){
				Ihm.log("Detection de contour");
				myIhm.log.append("\n> Filtre Detection de contour");
				myIhm.client.demandeTraitement(Ihm.Cont, false, false, false);

				myIhm.imageModified = true;

			}
			else{
				JOptionPane jOpt = new JOptionPane();
				jOpt.showMessageDialog(myIhm, "Veuillez configurer tous les paramètres réseau et charger une image d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}

		// application du filtre saturation
		else if (e.getActionCommand().equals("saturation")) {

			if (myIhm.loadOrNot && myIhm.configReseauOrNot){
				Ihm.log("Saturation");
				myIhm.log.append("\n> Filtre saturation");
				myIhm.client.demandeTraitement(Ihm.Satur, false, false, false);

				myIhm.imageModified = true;

			}
			else{
				JOptionPane jOpt = new JOptionPane();
				jOpt.showMessageDialog(myIhm, "Veuillez configurer tous les paramètres réseau et charger une image d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}

		// lancement de la terminaison des serveurs
		else if (e.getActionCommand().equals("terminer")){
			if (myIhm.loadOrNot && myIhm.configReseauOrNot){
				myIhm.client.demandeTerminaison();
			}
			else{
				JOptionPane jOpt = new JOptionPane();
				jOpt.showMessageDialog(myIhm, "Veuillez configurer tous les paramètres réseau et charger une image d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
		}

		// cas de l'annulation du dernier filtre appliqué
		else if (e.getActionCommand().equals("unDo")){
			if (myIhm.pixelPrec!=null) {
				myIhm.log.append("\n> Annulation du dernier filtre");
				myIhm.activeSuivant();
				try {
					myIhm.pixelSuiv = myIhm.getImageLoadBuff().getRGB(0, 0, myIhm.getClient().getImage().getWidth(), myIhm.getClient().getImage().getHeight(),
							myIhm.pixelSuiv, 0, myIhm.getClient().getImage().getWidth());

					myIhm.getImageLoadBuff().setRGB(0, 0, myIhm.getClient().getImage().getWidth(),
							myIhm.getClient().getImage().getHeight(), myIhm.pixelPrec, 0, myIhm.getClient().getImage().getWidth());
					myIhm.pixelPrec = null;
				} catch (RemoteException e1) {
					e1.printStackTrace();
				}
				myIhm.unDo.setEnabled(false);
				myIhm.refreshImage();

			}
		}

		// cas du rétablissement du dernier filtre annulé
		else if (e.getActionCommand().equals("reDo")){
			if (myIhm.pixelSuiv!=null) {
				myIhm.log.append("\n> Restauraton du dernier filtre");
				try {
					myIhm.pixelPrec = myIhm.getImageLoadBuff().getRGB(0, 0, myIhm.getClient().getImage().getWidth(), myIhm.getClient().getImage().getHeight(),
							myIhm.pixelPrec, 0, myIhm.getClient().getImage().getWidth());

					myIhm.getImageLoadBuff().setRGB(0, 0, myIhm.getClient().getImage().getWidth(),
							myIhm.getClient().getImage().getHeight(), myIhm.pixelSuiv, 0, myIhm.getClient().getImage().getWidth());
					myIhm.pixelSuiv =null;

				} catch (RemoteException e1) {
					e1.printStackTrace();
				}
				myIhm.refreshImage();
				myIhm.pixelSuiv = null;
				myIhm.reDo.setEnabled(false);
				myIhm.activePrecedent();
			}
		}

		//cas de la configuration du nombre de portions relatives au découpage
		else if(e.getActionCommand().equals("decoupe")){
			new Ihm_Parametre_Portion(myIhm);
		}

		//cas de la configuration des parametres réseaux du client
		else if (e.getActionCommand().equals("config_connexion_client")){
			new Ihm_Parametre_Client(myIhm);
		}

		//cas de la configuration des parametres réseaux du serveur
		else if (e.getActionCommand().equals("config_connexion_serveur")){
			new Ihm_Parametre_Serveur(myIhm);
		}


	}


	/**
	 * enregistrement d'une image
	 */
	private void save(){
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File(myIhm.currentFolder));
		chooser.setDialogTitle("Enregistrement");
		if (chooser.showSaveDialog(myIhm) == JFileChooser.APPROVE_OPTION) {
			try {
				ImageIO.write(myIhm.getImageLoadBuff(), "png", new java.io.File(chooser.getSelectedFile().getAbsolutePath()));
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(myIhm, e1.getMessage(),"Erreur",JOptionPane.ERROR_MESSAGE);
			}
		}

	}


	/*
	 * focntion de gestion des traitements relatifs au filtre RVB   
	 */
	@Override
	public void itemStateChanged(ItemEvent e) {
		JCheckBoxMenuItem source = (JCheckBoxMenuItem) e.getItemSelectable();

		if (source.isEnabled()) {

			if (myIhm.jcMenuRouge.isSelected() && myIhm.jcMenuVert.isSelected() && myIhm.jcMenuBleu.isSelected()){
				rvb(true, true, true);
			}
			else
				if (myIhm.jcMenuRouge.isSelected() && !myIhm.jcMenuVert.isSelected() && myIhm.jcMenuBleu.isSelected()){
					rvb(true, false, true);
				}
				else if (myIhm.jcMenuRouge.isSelected() && !myIhm.jcMenuVert.isSelected() && !myIhm.jcMenuBleu.isSelected()){
					rvb(true, false, false);System.out.println("3");
				}
				else if (!myIhm.jcMenuRouge.isSelected() && !myIhm.jcMenuVert.isSelected() && !myIhm.jcMenuBleu.isSelected()){
					rvb(false, false, false);
				}
				else if (!myIhm.jcMenuRouge.isSelected() && myIhm.jcMenuVert.isSelected() && myIhm.jcMenuBleu.isSelected()){
					rvb(false, true, true);
				}
				else if (!myIhm.jcMenuRouge.isSelected() && !myIhm.jcMenuVert.isSelected() && myIhm.jcMenuBleu.isSelected()){
					rvb(false, false, true);
				}
				else if (!myIhm.jcMenuRouge.isSelected() && myIhm.jcMenuVert.isSelected() && !myIhm.jcMenuBleu.isSelected()){
					rvb(false, true, false);
				}
				else if (myIhm.jcMenuRouge.isSelected() && myIhm.jcMenuVert.isSelected() && !myIhm.jcMenuBleu.isSelected()){
					rvb(true, true, false);
				}


		}
	}

	/**
	 * fonction de lancement du filtre RVB
	 * @param r
	 * @param v
	 * @param b
	 */
	@SuppressWarnings("static-access")
	private void rvb(boolean r, boolean v, boolean b) {
		if (myIhm.loadOrNot && myIhm.configReseauOrNot){

			Ihm.log("RVB");
			myIhm.log.append("\n> Filtre RVB");
			myIhm.client.demandeTraitement(Ihm.rvb, r, v, b);
			myIhm.imageModified = true;

		}
		else{
			JOptionPane jOpt = new JOptionPane();
			jOpt.showMessageDialog(myIhm, "Veuillez configurer tous les paramètres réseau et charger une image d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
		}
	}



}
