package ihm.server;

import ihm.client.Ihm_Parametre_Serveur;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;

import pack.IObservable;
import pack.IObserver;
import pack.Machine;
import reseau.IReseau;
import serveur.Serveur;
import serveur.ThreadServeur;

/**
 * IHM principal de lancement du serveur. elle permet de configurer un serveur et de suivre toute l'activité de 
 * celui-ci à travers les logs
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Serveur extends JFrame implements IObserver{

	private static final long serialVersionUID = 1L;
	private JTextArea log;
	JScrollPane jcPan;
	JToolBar tb;
	JButton config, lancer, configServSuiv, clear;
	private Serveur serveur;
	IReseau reseau;
	Machine machineReseau;

	public Ihm_Serveur() {
		setServeur(null);
		reseau =null;
		machineReseau = null;
		setTitle("Console Serveur...");
		setSize(new Dimension(500, 450));
		this.setLocation(200, 100);
		tb = new JToolBar();
		setLog(new JTextArea());
		getLog().setAutoscrolls(true);
		getLog().setEditable(false);
		jcPan = new JScrollPane(getLog());

		config = new JButton("Config serveur");
		config.setActionCommand("config");
		config.addActionListener(new Ecouteur());

		configServSuiv = new JButton("Serveur Suivant");
		configServSuiv.setActionCommand("configServSuiv");
		configServSuiv.addActionListener(new Ecouteur());
		configServSuiv.setEnabled(false);

		lancer = new JButton("Demarrer");
		lancer.setActionCommand("demarrer");
		lancer.addActionListener(new Ecouteur());
		lancer.setEnabled(false);
		clear = new JButton("Effacer Log");
		clear.setActionCommand("clear");
		clear.addActionListener(new Ecouteur());
		tb.add(config);
		tb.add(configServSuiv);
		tb.add(lancer);
		tb.add(clear);
		JMenuBar mb = new JMenuBar();
		mb.add(tb);
		setJMenuBar(mb);
		setContentPane(jcPan);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});

	}

	public void setServeur(Serveur serveur) {
		this.serveur = serveur;
	}

	public Serveur getServeur() {
		return serveur;
	}

	public void setLog(JTextArea log) {
		this.log = log;
	}

	public JTextArea getLog() {
		return log;
	}

	public static void main(String[] arg){
		new Ihm_Serveur();
	}

	@Override
	public void updateLog(IObservable o, String info) {
		if (o instanceof Serveur || o instanceof ThreadServeur)
			log.append("\n> "+info);

	}

	class Ecouteur implements ActionListener{

		public void actionPerformed(ActionEvent arg0) {
			if (arg0.getActionCommand().equals("config")){
				new Ihm_Parametre_Serveur_Reseau(Ihm_Serveur.this);
			}

			else if(arg0.getActionCommand().equals("configServSuiv")){
				new Ihm_Parametre_Serveur(Ihm_Serveur.this);
			}

			else if(arg0.getActionCommand().equals("clear")){
				Ihm_Serveur.this.log.setText("");
			}

			else if (arg0.getActionCommand().equals("demarrer")){
				if (Ihm_Serveur.this.getServeur()!=null && Ihm_Serveur.this.machineReseau!=null){
					if (Ihm_Serveur.this.getServeur().connectReseau(Ihm_Serveur.this.machineReseau.nom,
							Ihm_Serveur.this.machineReseau.machine, Ihm_Serveur.this.machineReseau.port) == false){

						JOptionPane.showMessageDialog(Ihm_Serveur.this, "Erreur lors de la connexion à la machine Réseau !", "Erreur", JOptionPane.ERROR_MESSAGE);
						Ihm_Serveur.this.getLog().append("\n> Erreur lors de la connexion à la machine Réseau");
					}
					else{

						Ihm_Serveur.this.getLog().append("\n> Serveur " + Ihm_Serveur.this.getServeur().getMachineServeur().nom
								+ " créé  (Machine : " + Ihm_Serveur.this.getServeur().getMachineServeur().machine
								+ ", N° de port : " + Ihm_Serveur.this.getServeur().getMachineServeur().port + ", Nbre de Thread ="
								+ Ihm_Serveur.this.getServeur().getNbrProc()+")");

						Ihm_Serveur.this.getLog().append("\n> Connexion établie avec succès avec la machine Reseau");
					}

				}
				else
					JOptionPane.showMessageDialog(Ihm_Serveur.this, "Veillez configurer le serveur d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}

		}

	}


}
