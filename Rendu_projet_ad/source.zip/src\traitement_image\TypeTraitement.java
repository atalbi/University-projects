package traitement_image;

import java.io.Serializable;

/**
 * Classe définissant les propriétés relatives à un traitement d'image (type de filtre,...)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class TypeTraitement implements Serializable{

	private static final long serialVersionUID = 1L;
	int filtre;
	boolean r, v, b;

	public TypeTraitement(int filtre, boolean r, boolean v, boolean b) {
		this.filtre = filtre;
		this.r = r;
		this.v = v;
		this.b = b;
	}

	public int getFiltre() {
		return filtre;
	}

	public boolean isB() {
		return b;
	}

	public boolean isR() {
		return r;
	}

	public boolean isV() {
		return v;
	}

	public static String getDetailTraitement(int indice){
		String resultat = "";

		switch (indice) {

		case 1:
			resultat = "Niveaux de Gris";
			break;

		case 2:
			resultat = "Saturation";
			break;

		case 3:
			resultat = "Detection de Contour";
			break;

		case 4:
			resultat = "RVB";
			break;
		}
		return resultat;
	}
}
