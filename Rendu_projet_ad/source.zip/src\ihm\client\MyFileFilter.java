package ihm.client;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * Classe utilitaire pour le filtrage des extensions des fichiers affichés dans le sélecteur de fichier lors du 
 * choix de l'image à charger
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class MyFileFilter extends FileFilter {

	private String description;
	private String[] extensions;

	public MyFileFilter(String[] ext, String description){
		if(description == null){
			throw new NullPointerException("La description ne peut être null.");
		}
		this.description = description;
		this.extensions = ext;
	}


	public boolean accept(File file){
		if(file.isDirectory() || extensions.length==0) { 
			return true; 
		} 
		String nomFichier = file.getName().toLowerCase(); 
		for(String extension : extensions){
			if(nomFichier.endsWith(extension)){
				return true;
			}
		}
		return false;
	}

	public String getDescription(){
		StringBuffer buffer = new StringBuffer(description);
		buffer.append(" (");
		for(String extension : extensions){
			buffer.append(extension).append(" ");
		}
		return buffer.append(")").toString();
	}
}
