package jeton;

/**
 * Classe définissant les caractéristique d'un jeton Stop(jeton utilisé pour provoquer l'arrêt des serveurs)
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class JetonStop extends Jeton {

	private static final long serialVersionUID = 1L;
	
	public int nbServeurArret;

	public JetonStop() {
		super("");
		nbServeurArret=0;
	}
	
	
}
