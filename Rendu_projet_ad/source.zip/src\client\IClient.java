package client;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import traitement_image.Portion_Image;


/**
 * Interface Remote definissant les méthodes du client, accessibles à distance
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public interface IClient extends Remote {
	
	public void accepterPartieImage(Portion_Image partieImg)throws RemoteException, IOException;
	Portion_Image getPi(int i) throws RemoteException;
	
}
