package traitement_image;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;

/**
 * Classe représentant une portion d'image ainsi que ses caractéristiques
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Portion_Image implements Serializable{

	private static final long serialVersionUID = 1L;
	int debutX;
	int debutY;
	int largeur;
	int hauteur;
	private int[] pixel;
	int ordre;
	
	public Portion_Image() {
		
	}

	public BufferedImage getImageBuffer() throws IOException {
		BufferedImage dst = new BufferedImage(largeur, hauteur,
		BufferedImage.TYPE_INT_ARGB);
		dst.setRGB(0, 0, largeur, hauteur, pixel, 0, largeur);
		return dst;
	}
	
	public int getDebutX() {
		return debutX;
	}

	public void setDebutX(int debutX) {
		this.debutX = debutX;
	}

	public int getDebutY() {
		return debutY;
	}

	public void setDebutY(int debutY) {
		this.debutY = debutY;
	}

	public int getLargeur() {
		return largeur;
	}

	public void setLargeur(int largeur) {
		this.largeur = largeur;
	}

	public int getHauteur() {
		return hauteur;
	}

	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	
	public int getOrdre() {
		return ordre;
	}
	
	public void setOrdre(int ordre) {
		this.ordre = ordre;
	}
	
	public String toString(){
		return ("Portion d'image de hauteur: "+hauteur+"px, de  largeur: "+largeur+
				"px, de coordonnees en X: "+debutX+" de coordonnees en Y: "+debutY+
				" et longueur du tableau de pixel = "+getPixel().length);
	}

	public void setPixel(int[] pixel) {
		this.pixel = pixel;
	}

	public int[] getPixel() {
		return pixel;
	}
}
