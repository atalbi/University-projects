package ihm.reseau;

import ihm.client.Ihm_Parametre_Delai_Reseau;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.rmi.RemoteException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import pack.IObservable;
import pack.IObserver;
import reseau.Reseau;

/**
 * IHM permettant à l'administrateur de configurer les paramètres de la machine réseau ainsi que le délai
 * de communication
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Ihm_Reseau extends JFrame implements IObserver{


	private static final long serialVersionUID = 1L;
	JTextArea log;
	JScrollPane jcPan;
	JToolBar tb;
	JButton lancer, configDelai;
	Reseau reseau;
	JPanel jp, jp1;
	private JLabel lab1, lab2, lab3;
	private JTextField nomReseau, adresseReseau, portReseau;
	public static int delai = 2000;

	public Ihm_Reseau() {
		reseau =null;

		setTitle("Console Reseau...");
		setSize(new Dimension(350, 400));
		setResizable(false);
		this.setLocation(200, 100);
		tb = new JToolBar();
		log = new JTextArea(16, 31);
		log.setAutoscrolls(true);
		log.setEditable(false);
		jcPan = new JScrollPane(log);
		jp =new JPanel();
		jp1 =new JPanel();

		GridLayout grid = new GridLayout(3,2);
		jp.setLayout(grid);

		nomReseau = new JTextField();
		nomReseau.setText("Machine_Reseau");
		lab1 = new JLabel("Nom machine Reseau  ");
		adresseReseau = new JTextField();
		try {
			adresseReseau.setText(Inet4Address.getLocalHost().getHostName());
		} catch (UnknownHostException e) {e.printStackTrace();}
		lab2 = new JLabel("Adresse machine Reseau ");
		portReseau = new JTextField();
		portReseau.setText("8000");
		lab3 = new JLabel("Port machine Reseau");
		jp.add(lab1);
		jp.add(nomReseau);
		jp.add(lab2);
		jp.add(adresseReseau);
		jp.add(lab3);
		jp.add(portReseau);
		jp1.add(jp);
		jp1.add(jcPan);

		configDelai = new JButton("Config Delai");
		configDelai.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				new Ihm_Parametre_Delai_Reseau(Ihm_Reseau.this);

			}

		});

		lancer = new JButton("Start");
		lancer.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent arg0) {
				if (!adresseReseau.getText().equals("") &&
						!nomReseau.getText().equals("") && 
						!portReseau.getText().equals("")) {

					try {
						reseau = new Reseau(nomReseau.getText(), adresseReseau.getText(),
								Integer.parseInt(portReseau.getText()), Ihm_Reseau.this);
						log.append("\n> Parametres réseaux(Nom: "+reseau.getMachineReseau().nom+
								", adresse: "+reseau.getMachineReseau().machine+", port:"+reseau.getMachineReseau().port+") configurés avec succès");
						lancer.setEnabled(false);
					}
					catch (NumberFormatException e) {

						JOptionPane.showMessageDialog(Ihm_Reseau.this, "Erreur sur le format du numero de port saisi !", "Erreur", JOptionPane.ERROR_MESSAGE);
						log.append("\n> Erreur sur le format du numero de port saisi ");
						e.printStackTrace();
					} catch (RemoteException e) {

						JOptionPane.showMessageDialog(Ihm_Reseau.this, "Erreur lors de l'enregistrement dans le registry  !", "Erreur", JOptionPane.ERROR_MESSAGE);
						log.append("\n> Erreur de type RemoteException lors de l'enregistrement de la machine dans le Registry  ");
						e.printStackTrace();
					}
				}
				else
					JOptionPane.showMessageDialog(Ihm_Reseau.this, "Veillez saisir les parametres reseaux d'abord !", "Erreur", JOptionPane.ERROR_MESSAGE);
			}

		});

		tb.add(lancer);
		tb.add(configDelai);
		JMenuBar mb = new JMenuBar();
		mb.add(tb);
		setJMenuBar(mb);
		setContentPane(jp1);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				dispose();
			}
		});

	}

	public JTextArea getLog() {
		return log;
	}


	@Override
	public void updateLog(IObservable o, String info) {
		if (o instanceof Reseau)
			log.append("\n> "+info);

	}

	public static void main(String[] arg){
		new Ihm_Reseau();
	}
}
