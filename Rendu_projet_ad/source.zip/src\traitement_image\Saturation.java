package traitement_image;


/**
 * Classe utilitaire permettant d'appliquer le filtre Saturation d'intensité -200 sur une image ou une portion d'image
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class Saturation{
	static int saturation = -200;

	public Saturation(int intens) {
		super();
		saturation = intens;
	}


	public static int[] filtrerImage(int width, int height, int[] srcPixels) {

		int dstPixels[] = new int[srcPixels.length];

		for(int X=0; X<srcPixels.length; X++)  {
			int r = 0, g = 0, b = 0; 
			int moy = 0;
			r = (int)getRed(srcPixels[X]);
			g = (int)getGreen(srcPixels[X]);
			b = (int)getBlue(srcPixels[X]);

			moy = (r + g + b) / 3;

			r = (int) (r + saturation / 100. * (r - moy));
			g = (int) (g + saturation / 100. * (g - moy));
			b = (int) (b + saturation / 100. * (b - moy));

			if (r < 0)
				r = 0;
			if (r > 255)
				r = 255;
			if (g < 0)
				g = 0;
			if (g > 255)
				g = 255;
			if (b < 0)
				b = 0;
			if (b > 255)
				b = 255;

			int newRGB = (0xff << 24) + (r << 16) + (g << 8) + (b);

			dstPixels[X] = newRGB;
		}

		return dstPixels;
	}

	public static int getRed(int pixel) {
		int tmp = pixel & 0x00FF0000;
		return tmp >> 16;
	}
	public static int getGreen(int pixel) {
		int tmp = pixel & 0x0000FF00;
		return tmp >> 8;
	}
	public static int getBlue(int pixel) {
		int tmp = pixel & 0x000000FF;
		return tmp;
	}


}
