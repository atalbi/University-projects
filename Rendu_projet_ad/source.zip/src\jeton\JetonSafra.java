package jeton;

/**
 * Classe représentant le jeton qui permet de déterminer la terminaison du système
 *  @author Amine TALBI & Hugues FAGNINOU
 *
 */
public class JetonSafra extends Jeton {

	private static final long serialVersionUID = 1L;
	public int c; //couleur du jeton
	public int compteur; //compteur 

	public JetonSafra(int c, int conteur) {
		super("");
		this.c = c;
		this.compteur = conteur;
	}

}
